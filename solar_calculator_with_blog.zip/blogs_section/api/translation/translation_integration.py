"""
تكامل ميزة الترجمة التلقائية مع تطبيق Flask
"""

from flask import Blueprint, render_template, redirect, url_for, request, session, g
from api.translation.translation_api import translation_bp, with_auto_translation, get_browser_language

def register_translation_routes(app):
    """
    تسجيل مسارات الترجمة في تطبيق Flask
    
    المعلمات:
        app: تطبيق Flask
    """
    # تسجيل Blueprint للترجمة
    app.register_blueprint(translation_bp)
    
    # إضافة مسار صفحة اختيار اللغة
    @app.route('/language')
    def language_selector():
        return render_template('translation/language_selector.html')
    
    # إضافة مزخرف قبل الطلب لتعيين لغة المستخدم
    @app.before_request
    def set_user_language():
        # تحديد لغة المستخدم من الجلسة أو من المتصفح
        g.language = session.get('language') or get_browser_language()
    
    # إضافة متغيرات الترجمة إلى سياق القالب
    @app.context_processor
    def translation_variables():
        return {
            'current_language': g.get('language', 'ar'),
            'is_rtl': g.get('language', 'ar') in ['ar'],
            'get_translated_url': get_translated_url
        }

def get_translated_url(path=None):
    """
    الحصول على عنوان URL مع معلمة اللغة
    
    المعلمات:
        path: المسار (اختياري، يستخدم المسار الحالي إذا لم يتم تحديده)
    
    العائد:
        str: عنوان URL مع معلمة اللغة
    """
    if path is None:
        path = request.path
    
    # إضافة معلمة اللغة إلى عنوان URL
    language = g.get('language', 'ar')
    
    # إذا كان المسار يحتوي بالفعل على معلمة اللغة، استبدلها
    if 'lang=' in request.full_path:
        return request.full_path.replace(
            f"lang={request.args.get('lang')}", 
            f"lang={language}"
        )
    
    # إضافة معلمة اللغة إلى عنوان URL
    separator = '&' if '?' in request.full_path else '?'
    return f"{request.full_path}{separator}lang={language}"
