"""
وحدة التكامل مع Blogger API
توفر هذه الوحدة الوظائف اللازمة للتفاعل مع Blogger API
"""

import os
from googleapiclient.discovery import build
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
import pickle
import json

from ..config import api_config

class BloggerAPI:
    """فئة للتعامل مع Blogger API"""
    
    def __init__(self):
        """تهيئة الاتصال بـ Blogger API"""
        self.scopes = api_config.BLOGGER_SCOPES
        self.api_key = api_config.BLOGGER_API_KEY
        self.blog_id = api_config.BLOG_ID
        self.creds = None
        self.service = None
    
    def authenticate(self):
        """إجراء المصادقة مع Blogger API"""
        # التحقق من وجود ملف التوكن
        token_path = os.path.join(os.path.dirname(__file__), 'token.pickle')
        
        if os.path.exists(token_path):
            with open(token_path, 'rb') as token:
                self.creds = pickle.load(token)
        
        # إذا لم تكن هناك بيانات اعتماد صالحة، قم بإنشاء جديدة
        if not self.creds or not self.creds.valid:
            if self.creds and self.creds.expired and self.creds.refresh_token:
                self.creds.refresh(Request())
            else:
                # إنشاء ملف client_secrets.json
                client_config = {
                    "installed": {
                        "client_id": api_config.CLIENT_ID,
                        "client_secret": api_config.CLIENT_SECRET,
                        "redirect_uris": [api_config.REDIRECT_URI, "urn:ietf:wg:oauth:2.0:oob"],
                        "auth_uri": "https://accounts.google.com/o/oauth2/auth",
                        "token_uri": "https://oauth2.googleapis.com/token"
                    }
                }
                
                client_secrets_path = os.path.join(os.path.dirname(__file__), 'client_secrets.json')
                with open(client_secrets_path, 'w') as f:
                    json.dump(client_config, f)
                
                flow = InstalledAppFlow.from_client_secrets_file(
                    client_secrets_path, self.scopes)
                self.creds = flow.run_local_server(port=0)
            
            # حفظ بيانات الاعتماد للمرة القادمة
            with open(token_path, 'wb') as token:
                pickle.dump(self.creds, token)
        
        # إنشاء خدمة Blogger API
        self.service = build('blogger', 'v3', credentials=self.creds)
        return self.service
    
    def get_service_with_api_key(self):
        """الحصول على خدمة Blogger API باستخدام مفتاح API"""
        return build('blogger', 'v3', developerKey=self.api_key)
    
    def get_blog_info(self):
        """الحصول على معلومات المدونة"""
        if not self.service:
            self.authenticate()
        
        return self.service.blogs().get(blogId=self.blog_id).execute()
    
    def list_posts(self, max_results=10, status=None):
        """الحصول على قائمة المنشورات
        
        المعلمات:
            max_results (int): الحد الأقصى لعدد النتائج
            status (str): حالة المنشورات (LIVE, DRAFT, SCHEDULED)
        
        العائد:
            dict: قائمة المنشورات
        """
        if not self.service:
            self.authenticate()
        
        params = {
            'blogId': self.blog_id,
            'maxResults': max_results
        }
        
        if status:
            params['status'] = status
        
        return self.service.posts().list(**params).execute()
    
    def get_post(self, post_id):
        """الحصول على منشور محدد
        
        المعلمات:
            post_id (str): معرف المنشور
        
        العائد:
            dict: بيانات المنشور
        """
        if not self.service:
            self.authenticate()
        
        return self.service.posts().get(blogId=self.blog_id, postId=post_id).execute()
    
    def create_post(self, title, content, labels=None, is_draft=False):
        """إنشاء منشور جديد
        
        المعلمات:
            title (str): عنوان المنشور
            content (str): محتوى المنشور (HTML)
            labels (list): قائمة التصنيفات
            is_draft (bool): هل المنشور مسودة
        
        العائد:
            dict: بيانات المنشور الجديد
        """
        if not self.service:
            self.authenticate()
        
        post_body = {
            'title': title,
            'content': content
        }
        
        if labels:
            post_body['labels'] = labels
        
        if is_draft:
            post_body['status'] = 'DRAFT'
        
        return self.service.posts().insert(blogId=self.blog_id, body=post_body).execute()
    
    def update_post(self, post_id, title=None, content=None, labels=None):
        """تحديث منشور موجود
        
        المعلمات:
            post_id (str): معرف المنشور
            title (str): عنوان المنشور الجديد
            content (str): محتوى المنشور الجديد (HTML)
            labels (list): قائمة التصنيفات الجديدة
        
        العائد:
            dict: بيانات المنشور المحدث
        """
        if not self.service:
            self.authenticate()
        
        # الحصول على المنشور الحالي
        post = self.get_post(post_id)
        
        # تحديث البيانات
        if title:
            post['title'] = title
        
        if content:
            post['content'] = content
        
        if labels:
            post['labels'] = labels
        
        return self.service.posts().update(blogId=self.blog_id, postId=post_id, body=post).execute()
    
    def delete_post(self, post_id):
        """حذف منشور
        
        المعلمات:
            post_id (str): معرف المنشور
        
        العائد:
            dict: استجابة الحذف
        """
        if not self.service:
            self.authenticate()
        
        return self.service.posts().delete(blogId=self.blog_id, postId=post_id).execute()
    
    def list_comments(self, post_id=None, max_results=10):
        """الحصول على قائمة التعليقات
        
        المعلمات:
            post_id (str): معرف المنشور (اختياري)
            max_results (int): الحد الأقصى لعدد النتائج
        
        العائد:
            dict: قائمة التعليقات
        """
        if not self.service:
            self.authenticate()
        
        if post_id:
            return self.service.comments().list(
                blogId=self.blog_id,
                postId=post_id,
                maxResults=max_results
            ).execute()
        else:
            return self.service.comments().listByBlog(
                blogId=self.blog_id,
                maxResults=max_results
            ).execute()
    
    def approve_comment(self, post_id, comment_id):
        """الموافقة على تعليق
        
        المعلمات:
            post_id (str): معرف المنشور
            comment_id (str): معرف التعليق
        
        العائد:
            dict: بيانات التعليق المحدث
        """
        if not self.service:
            self.authenticate()
        
        return self.service.comments().approve(
            blogId=self.blog_id,
            postId=post_id,
            commentId=comment_id
        ).execute()
    
    def mark_comment_as_spam(self, post_id, comment_id):
        """تعليم تعليق كرسائل غير مرغوب فيها
        
        المعلمات:
            post_id (str): معرف المنشور
            comment_id (str): معرف التعليق
        
        العائد:
            dict: بيانات التعليق المحدث
        """
        if not self.service:
            self.authenticate()
        
        return self.service.comments().markAsSpam(
            blogId=self.blog_id,
            postId=post_id,
            commentId=comment_id
        ).execute()
    
    def delete_comment(self, post_id, comment_id):
        """حذف تعليق
        
        المعلمات:
            post_id (str): معرف المنشور
            comment_id (str): معرف التعليق
        
        العائد:
            dict: استجابة الحذف
        """
        if not self.service:
            self.authenticate()
        
        return self.service.comments().delete(
            blogId=self.blog_id,
            postId=post_id,
            commentId=comment_id
        ).execute()
    
    def search_posts(self, query):
        """البحث في المنشورات
        
        المعلمات:
            query (str): نص البحث
        
        العائد:
            dict: نتائج البحث
        """
        if not self.service:
            self.authenticate()
        
        return self.service.posts().search(
            blogId=self.blog_id,
            q=query
        ).execute()
