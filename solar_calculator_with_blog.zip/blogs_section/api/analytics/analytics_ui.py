"""
وحدة واجهة المستخدم لتحليلات Google Analytics
توفر هذه الوحدة واجهة مستخدم للتفاعل مع Google Analytics API
"""

from flask import Blueprint, render_template, request, redirect, url_for, flash, session, jsonify
import os
from ..api.analytics.analytics_api import AnalyticsAPI

analytics_bp = Blueprint('analytics', __name__)
analytics_api = AnalyticsAPI()

@analytics_bp.route('/admin/analytics')
def admin_analytics():
    """صفحة إدارة Google Analytics"""
    if not session.get('authenticated'):
        return redirect(url_for('admin_login'))
    
    try:
        # الحصول على معلومات الخاصية
        property_info = analytics_api.get_property_info()
        
        # الحصول على تقرير عام
        report = analytics_api.run_report()
        
        # الحصول على تقرير في الوقت الحقيقي
        realtime_report = analytics_api.get_realtime_report()
        
        return render_template('admin/analytics.html', 
                              property=property_info, 
                              report=report,
                              realtime_report=realtime_report)
    except Exception as e:
        flash(f'حدث خطأ: {str(e)}', 'error')
        return render_template('admin/analytics.html', 
                              property={}, 
                              report={},
                              realtime_report={})

@analytics_bp.route('/admin/analytics/popular_pages')
def admin_popular_pages():
    """صفحة الصفحات الأكثر شعبية"""
    if not session.get('authenticated'):
        return redirect(url_for('admin_login'))
    
    start_date = request.args.get('start_date')
    end_date = request.args.get('end_date')
    limit = request.args.get('limit', 10, type=int)
    
    try:
        report = analytics_api.get_popular_pages(start_date, end_date, limit)
        return render_template('admin/popular_pages.html', 
                              report=report,
                              start_date=start_date,
                              end_date=end_date,
                              limit=limit)
    except Exception as e:
        flash(f'حدث خطأ: {str(e)}', 'error')
        return render_template('admin/popular_pages.html', 
                              report={},
                              start_date=start_date,
                              end_date=end_date,
                              limit=limit)

@analytics_bp.route('/admin/analytics/traffic_sources')
def admin_traffic_sources():
    """صفحة مصادر حركة المرور"""
    if not session.get('authenticated'):
        return redirect(url_for('admin_login'))
    
    start_date = request.args.get('start_date')
    end_date = request.args.get('end_date')
    limit = request.args.get('limit', 10, type=int)
    
    try:
        report = analytics_api.get_traffic_sources(start_date, end_date, limit)
        return render_template('admin/traffic_sources.html', 
                              report=report,
                              start_date=start_date,
                              end_date=end_date,
                              limit=limit)
    except Exception as e:
        flash(f'حدث خطأ: {str(e)}', 'error')
        return render_template('admin/traffic_sources.html', 
                              report={},
                              start_date=start_date,
                              end_date=end_date,
                              limit=limit)

@analytics_bp.route('/admin/analytics/user_demographics')
def admin_user_demographics():
    """صفحة البيانات الديموغرافية للمستخدمين"""
    if not session.get('authenticated'):
        return redirect(url_for('admin_login'))
    
    start_date = request.args.get('start_date')
    end_date = request.args.get('end_date')
    limit = request.args.get('limit', 10, type=int)
    
    try:
        report = analytics_api.get_user_demographics(start_date, end_date, limit)
        return render_template('admin/user_demographics.html', 
                              report=report,
                              start_date=start_date,
                              end_date=end_date,
                              limit=limit)
    except Exception as e:
        flash(f'حدث خطأ: {str(e)}', 'error')
        return render_template('admin/user_demographics.html', 
                              report={},
                              start_date=start_date,
                              end_date=end_date,
                              limit=limit)

@analytics_bp.route('/admin/analytics/user_devices')
def admin_user_devices():
    """صفحة أجهزة المستخدمين"""
    if not session.get('authenticated'):
        return redirect(url_for('admin_login'))
    
    start_date = request.args.get('start_date')
    end_date = request.args.get('end_date')
    limit = request.args.get('limit', 10, type=int)
    
    try:
        report = analytics_api.get_user_devices(start_date, end_date, limit)
        return render_template('admin/user_devices.html', 
                              report=report,
                              start_date=start_date,
                              end_date=end_date,
                              limit=limit)
    except Exception as e:
        flash(f'حدث خطأ: {str(e)}', 'error')
        return render_template('admin/user_devices.html', 
                              report={},
                              start_date=start_date,
                              end_date=end_date,
                              limit=limit)

@analytics_bp.route('/admin/analytics/tracking_code')
def admin_tracking_code():
    """صفحة كود التتبع"""
    if not session.get('authenticated'):
        return redirect(url_for('admin_login'))
    
    try:
        tracking_code = analytics_api.get_tracking_code()
        return render_template('admin/tracking_code.html', 
                              tracking_code=tracking_code)
    except Exception as e:
        flash(f'حدث خطأ: {str(e)}', 'error')
        return render_template('admin/tracking_code.html', 
                              tracking_code="")

@analytics_bp.route('/api/analytics/realtime', methods=['GET'])
def get_realtime_data():
    """واجهة برمجة للحصول على بيانات في الوقت الحقيقي"""
    if not session.get('authenticated'):
        return jsonify({'error': 'غير مصرح'}), 401
    
    try:
        realtime_report = analytics_api.get_realtime_report()
        return jsonify(realtime_report)
    except Exception as e:
        return jsonify({'error': str(e)}), 500
