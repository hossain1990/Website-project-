"""
وحدة دمج AdSense في واجهة المستخدم
توفر هذه الوحدة الوظائف اللازمة لدمج إعلانات AdSense في صفحات المدونة
"""

from flask import Blueprint, render_template, request, redirect, url_for, flash, session, jsonify
import os
from ..api.adsense.adsense_api import AdSenseAPI

adsense_bp = Blueprint('adsense', __name__)
adsense_api = AdSenseAPI()

@adsense_bp.route('/admin/adsense')
def admin_adsense():
    """صفحة إدارة AdSense"""
    if not session.get('authenticated'):
        return redirect(url_for('admin_login'))
    
    try:
        account_info = adsense_api.get_account_info()
        ad_clients = adsense_api.list_ad_clients()
        
        # الحصول على تقرير الأرباح للشهر الحالي
        earnings_report = adsense_api.get_account_earnings()
        
        return render_template('admin/adsense.html', 
                              account=account_info, 
                              ad_clients=ad_clients.get('adClients', []),
                              earnings=earnings_report)
    except Exception as e:
        flash(f'حدث خطأ: {str(e)}', 'error')
        return render_template('admin/adsense.html', 
                              account={}, 
                              ad_clients=[],
                              earnings={})

@adsense_bp.route('/admin/adsense/ad_units/<ad_client_id>')
def admin_ad_units(ad_client_id):
    """صفحة إدارة وحدات الإعلانات"""
    if not session.get('authenticated'):
        return redirect(url_for('admin_login'))
    
    try:
        ad_units = adsense_api.list_ad_units(ad_client_id)
        return render_template('admin/ad_units.html', 
                              ad_client_id=ad_client_id,
                              ad_units=ad_units.get('adUnits', []))
    except Exception as e:
        flash(f'حدث خطأ: {str(e)}', 'error')
        return render_template('admin/ad_units.html', 
                              ad_client_id=ad_client_id,
                              ad_units=[])

@adsense_bp.route('/admin/adsense/ad_code/<ad_client_id>/<ad_unit_id>')
def admin_ad_code(ad_client_id, ad_unit_id):
    """الحصول على كود الإعلان"""
    if not session.get('authenticated'):
        return redirect(url_for('admin_login'))
    
    try:
        ad_code = adsense_api.get_ad_code(ad_client_id, ad_unit_id)
        return render_template('admin/ad_code.html', 
                              ad_client_id=ad_client_id,
                              ad_unit_id=ad_unit_id,
                              ad_code=ad_code)
    except Exception as e:
        flash(f'حدث خطأ: {str(e)}', 'error')
        return render_template('admin/ad_code.html', 
                              ad_client_id=ad_client_id,
                              ad_unit_id=ad_unit_id,
                              ad_code="")

@adsense_bp.route('/admin/adsense/earnings')
def admin_earnings():
    """صفحة تقارير الأرباح"""
    if not session.get('authenticated'):
        return redirect(url_for('admin_login'))
    
    start_date = request.args.get('start_date')
    end_date = request.args.get('end_date')
    
    try:
        earnings_report = adsense_api.get_account_earnings(start_date, end_date)
        return render_template('admin/earnings.html', 
                              earnings=earnings_report,
                              start_date=start_date,
                              end_date=end_date)
    except Exception as e:
        flash(f'حدث خطأ: {str(e)}', 'error')
        return render_template('admin/earnings.html', 
                              earnings={},
                              start_date=start_date,
                              end_date=end_date)

@adsense_bp.route('/admin/adsense/ad_unit_earnings/<ad_unit_id>')
def admin_ad_unit_earnings(ad_unit_id):
    """صفحة تقارير أرباح وحدة إعلانية محددة"""
    if not session.get('authenticated'):
        return redirect(url_for('admin_login'))
    
    start_date = request.args.get('start_date')
    end_date = request.args.get('end_date')
    
    try:
        earnings_report = adsense_api.get_ad_unit_earnings(ad_unit_id, start_date, end_date)
        return render_template('admin/ad_unit_earnings.html', 
                              earnings=earnings_report,
                              ad_unit_id=ad_unit_id,
                              start_date=start_date,
                              end_date=end_date)
    except Exception as e:
        flash(f'حدث خطأ: {str(e)}', 'error')
        return render_template('admin/ad_unit_earnings.html', 
                              earnings={},
                              ad_unit_id=ad_unit_id,
                              start_date=start_date,
                              end_date=end_date)

@adsense_bp.route('/api/adsense/generate_ad_code', methods=['POST'])
def generate_ad_code():
    """واجهة برمجة لإنشاء كود إعلان"""
    if not session.get('authenticated'):
        return jsonify({'error': 'غير مصرح'}), 401
    
    ad_type = request.form.get('ad_type')
    ad_client_id = request.form.get('ad_client_id')
    ad_unit_id = request.form.get('ad_unit_id')
    
    try:
        if ad_type == 'responsive':
            ad_code = adsense_api.generate_responsive_ad_code(ad_client_id)
        elif ad_type == 'in_article':
            ad_code = adsense_api.generate_in_article_ad_code(ad_client_id)
        elif ad_type == 'auto':
            ad_code = adsense_api.generate_auto_ads_code(ad_client_id)
        elif ad_type == 'custom' and ad_unit_id:
            ad_code = adsense_api.get_ad_code(ad_client_id, ad_unit_id)
        else:
            return jsonify({'error': 'نوع إعلان غير صالح'}), 400
        
        return jsonify({'ad_code': ad_code})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# دالة مساعدة لإنشاء أكواد الإعلانات للقوالب
def get_ad_codes(ad_client_id):
    """الحصول على أكواد الإعلانات المختلفة
    
    المعلمات:
        ad_client_id (str): معرف عميل الإعلانات
    
    العائد:
        dict: قاموس يحتوي على أكواد الإعلانات المختلفة
    """
    try:
        responsive_ad = adsense_api.generate_responsive_ad_code(ad_client_id)
        in_article_ad = adsense_api.generate_in_article_ad_code(ad_client_id)
        auto_ads = adsense_api.generate_auto_ads_code(ad_client_id)
        
        return {
            'responsive': responsive_ad,
            'in_article': in_article_ad,
            'auto': auto_ads
        }
    except Exception as e:
        print(f"خطأ في الحصول على أكواد الإعلانات: {str(e)}")
        return {
            'responsive': '',
            'in_article': '',
            'auto': ''
        }
