"""
وحدة التكامل مع Search Console API
توفر هذه الوحدة الوظائف اللازمة للتفاعل مع Search Console API
"""

import os
from googleapiclient.discovery import build
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
import pickle
import json
import datetime

from ..config import api_config

class SearchConsoleAPI:
    """فئة للتعامل مع Search Console API"""
    
    def __init__(self):
        """تهيئة الاتصال بـ Search Console API"""
        self.scopes = api_config.SEARCH_CONSOLE_SCOPES
        self.api_key = api_config.SEARCH_CONSOLE_API_KEY
        self.site_url = api_config.SEARCH_CONSOLE_SITE_URL
        self.creds = None
        self.service = None
    
    def authenticate(self):
        """إجراء المصادقة مع Search Console API"""
        # التحقق من وجود ملف التوكن
        token_path = os.path.join(os.path.dirname(__file__), 'search_console_token.pickle')
        
        if os.path.exists(token_path):
            with open(token_path, 'rb') as token:
                self.creds = pickle.load(token)
        
        # إذا لم تكن هناك بيانات اعتماد صالحة، قم بإنشاء جديدة
        if not self.creds or not self.creds.valid:
            if self.creds and self.creds.expired and self.creds.refresh_token:
                self.creds.refresh(Request())
            else:
                # إنشاء ملف client_secrets.json
                client_config = {
                    "installed": {
                        "client_id": api_config.CLIENT_ID,
                        "client_secret": api_config.CLIENT_SECRET,
                        "redirect_uris": [api_config.REDIRECT_URI, "urn:ietf:wg:oauth:2.0:oob"],
                        "auth_uri": "https://accounts.google.com/o/oauth2/auth",
                        "token_uri": "https://oauth2.googleapis.com/token"
                    }
                }
                
                client_secrets_path = os.path.join(os.path.dirname(__file__), 'search_console_client_secrets.json')
                with open(client_secrets_path, 'w') as f:
                    json.dump(client_config, f)
                
                flow = InstalledAppFlow.from_client_secrets_file(
                    client_secrets_path, self.scopes)
                self.creds = flow.run_local_server(port=0)
            
            # حفظ بيانات الاعتماد للمرة القادمة
            with open(token_path, 'wb') as token:
                pickle.dump(self.creds, token)
        
        # إنشاء خدمة Search Console API
        self.service = build('webmasters', 'v3', credentials=self.creds)
        return self.service
    
    def get_site_info(self):
        """الحصول على معلومات الموقع"""
        if not self.service:
            self.authenticate()
        
        return self.service.sites().get(siteUrl=self.site_url).execute()
    
    def list_sites(self):
        """الحصول على قائمة المواقع المتحقق منها"""
        if not self.service:
            self.authenticate()
        
        return self.service.sites().list().execute()
    
    def get_search_analytics(self, start_date=None, end_date=None, dimensions=None, search_type='web', row_limit=10):
        """الحصول على تحليلات البحث
        
        المعلمات:
            start_date (str): تاريخ البداية بتنسيق YYYY-MM-DD
            end_date (str): تاريخ النهاية بتنسيق YYYY-MM-DD
            dimensions (list): قائمة الأبعاد (query, page, country, device, date)
            search_type (str): نوع البحث (web, image, video, news, discover, googleNews)
            row_limit (int): الحد الأقصى لعدد الصفوف
        
        العائد:
            dict: نتائج تحليلات البحث
        """
        if not self.service:
            self.authenticate()
        
        # إذا لم يتم تحديد التواريخ، استخدم الشهر الحالي
        if not start_date or not end_date:
            today = datetime.date.today()
            end_date = today.strftime('%Y-%m-%d')
            start_date = (today - datetime.timedelta(days=30)).strftime('%Y-%m-%d')
        
        # إذا لم يتم تحديد الأبعاد، استخدم البعد الافتراضي (الاستعلام)
        if not dimensions:
            dimensions = ['query']
        
        # إعداد طلب تحليلات البحث
        request = {
            'startDate': start_date,
            'endDate': end_date,
            'dimensions': dimensions,
            'searchType': search_type,
            'rowLimit': row_limit
        }
        
        return self.service.searchanalytics().query(
            siteUrl=self.site_url,
            body=request
        ).execute()
    
    def get_top_queries(self, start_date=None, end_date=None, row_limit=10):
        """الحصول على أهم استعلامات البحث
        
        المعلمات:
            start_date (str): تاريخ البداية بتنسيق YYYY-MM-DD
            end_date (str): تاريخ النهاية بتنسيق YYYY-MM-DD
            row_limit (int): الحد الأقصى لعدد الصفوف
        
        العائد:
            dict: نتائج تحليلات البحث
        """
        return self.get_search_analytics(
            start_date=start_date,
            end_date=end_date,
            dimensions=['query'],
            row_limit=row_limit
        )
    
    def get_top_pages(self, start_date=None, end_date=None, row_limit=10):
        """الحصول على أهم الصفحات
        
        المعلمات:
            start_date (str): تاريخ البداية بتنسيق YYYY-MM-DD
            end_date (str): تاريخ النهاية بتنسيق YYYY-MM-DD
            row_limit (int): الحد الأقصى لعدد الصفوف
        
        العائد:
            dict: نتائج تحليلات البحث
        """
        return self.get_search_analytics(
            start_date=start_date,
            end_date=end_date,
            dimensions=['page'],
            row_limit=row_limit
        )
    
    def get_search_by_country(self, start_date=None, end_date=None, row_limit=10):
        """الحصول على تحليلات البحث حسب البلد
        
        المعلمات:
            start_date (str): تاريخ البداية بتنسيق YYYY-MM-DD
            end_date (str): تاريخ النهاية بتنسيق YYYY-MM-DD
            row_limit (int): الحد الأقصى لعدد الصفوف
        
        العائد:
            dict: نتائج تحليلات البحث
        """
        return self.get_search_analytics(
            start_date=start_date,
            end_date=end_date,
            dimensions=['country'],
            row_limit=row_limit
        )
    
    def get_search_by_device(self, start_date=None, end_date=None, row_limit=10):
        """الحصول على تحليلات البحث حسب الجهاز
        
        المعلمات:
            start_date (str): تاريخ البداية بتنسيق YYYY-MM-DD
            end_date (str): تاريخ النهاية بتنسيق YYYY-MM-DD
            row_limit (int): الحد الأقصى لعدد الصفوف
        
        العائد:
            dict: نتائج تحليلات البحث
        """
        return self.get_search_analytics(
            start_date=start_date,
            end_date=end_date,
            dimensions=['device'],
            row_limit=row_limit
        )
    
    def get_search_by_date(self, start_date=None, end_date=None, row_limit=10):
        """الحصول على تحليلات البحث حسب التاريخ
        
        المعلمات:
            start_date (str): تاريخ البداية بتنسيق YYYY-MM-DD
            end_date (str): تاريخ النهاية بتنسيق YYYY-MM-DD
            row_limit (int): الحد الأقصى لعدد الصفوف
        
        العائد:
            dict: نتائج تحليلات البحث
        """
        return self.get_search_analytics(
            start_date=start_date,
            end_date=end_date,
            dimensions=['date'],
            row_limit=row_limit
        )
    
    def list_sitemaps(self):
        """الحصول على قائمة خرائط الموقع"""
        if not self.service:
            self.authenticate()
        
        return self.service.sitemaps().list(siteUrl=self.site_url).execute()
    
    def submit_sitemap(self, sitemap_url):
        """إرسال خريطة موقع
        
        المعلمات:
            sitemap_url (str): عنوان URL لخريطة الموقع
        
        العائد:
            dict: نتيجة الإرسال
        """
        if not self.service:
            self.authenticate()
        
        return self.service.sitemaps().submit(
            siteUrl=self.site_url,
            feedpath=sitemap_url
        ).execute()
    
    def delete_sitemap(self, sitemap_url):
        """حذف خريطة موقع
        
        المعلمات:
            sitemap_url (str): عنوان URL لخريطة الموقع
        
        العائد:
            dict: نتيجة الحذف
        """
        if not self.service:
            self.authenticate()
        
        return self.service.sitemaps().delete(
            siteUrl=self.site_url,
            feedpath=sitemap_url
        ).execute()
    
    def get_url_inspection(self, url):
        """فحص عنوان URL
        
        المعلمات:
            url (str): عنوان URL للفحص
        
        العائد:
            dict: نتيجة الفحص
        """
        if not self.service:
            self.authenticate()
        
        # ملاحظة: هذه الوظيفة غير متوفرة في واجهة برمجة التطبيقات الحالية
        # وتم تضمينها هنا للتوضيح فقط
        
        # في الواقع، يمكن استخدام واجهة برمجة التطبيقات الجديدة للفحص
        # https://developers.google.com/webmaster-tools/search-console-api/reference/rest/v1/urlInspection
        
        return {
            'url': url,
            'status': 'NOT_IMPLEMENTED',
            'message': 'هذه الوظيفة غير متوفرة في واجهة برمجة التطبيقات الحالية'
        }
