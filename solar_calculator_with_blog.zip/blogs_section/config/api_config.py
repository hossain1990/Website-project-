# ملف تكوين واجهات برمجة التطبيقات

# بيانات اعتماد Google API
CLIENT_ID = "YOUR_CLIENT_ID"
CLIENT_SECRET = "YOUR_CLIENT_SECRET"
REDIRECT_URI = "http://localhost:5000/oauth2callback"

# نطاقات المصادقة
BLOGGER_SCOPES = [
    "https://www.googleapis.com/auth/blogger",
    "https://www.googleapis.com/auth/blogger.readonly"
]

ADSENSE_SCOPES = [
    "https://www.googleapis.com/auth/adsense",
    "https://www.googleapis.com/auth/adsense.readonly"
]

ANALYTICS_SCOPES = [
    "https://www.googleapis.com/auth/analytics",
    "https://www.googleapis.com/auth/analytics.readonly"
]

SEARCH_CONSOLE_SCOPES = [
    "https://www.googleapis.com/auth/webmasters",
    "https://www.googleapis.com/auth/webmasters.readonly"
]

# معرفات API
BLOGGER_API_KEY = "YOUR_BLOGGER_API_KEY"
ADSENSE_API_KEY = "YOUR_ADSENSE_API_KEY"
ANALYTICS_API_KEY = "YOUR_ANALYTICS_API_KEY"
SEARCH_CONSOLE_API_KEY = "YOUR_SEARCH_CONSOLE_API_KEY"

# معرفات المدونة
BLOG_ID = "YOUR_BLOG_ID"

# إعدادات AdSense
ADSENSE_ACCOUNT_ID = "YOUR_ADSENSE_ACCOUNT_ID"

# إعدادات Analytics
ANALYTICS_PROPERTY_ID = "YOUR_ANALYTICS_PROPERTY_ID"

# إعدادات Search Console
SEARCH_CONSOLE_SITE_URL = "YOUR_SITE_URL"
