/**
 * وحدة الترجمة التلقائية مع اكتشاف لغة المتصفح
 * توفر هذه الوحدة وظائف الترجمة التلقائية للمحتوى باستخدام واجهة برمجة الترجمة
 */

class TranslationAPI {
  /**
   * إنشاء كائن جديد من واجهة برمجة تطبيقات الترجمة
   * @param {Object} config - إعدادات التكوين
   */
  constructor(config = {}) {
    this.apiKey = config.apiKey || '';
    this.baseUrl = 'https://translation.googleapis.com/language/translate/v2';
    this.defaultLanguage = config.defaultLanguage || 'ar';
    this.supportedLanguages = config.supportedLanguages || ['ar', 'en', 'fr', 'es', 'de', 'it', 'ru', 'zh', 'ja', 'ko'];
    this.translationCache = {};
  }

  /**
   * استخراج لغة المتصفح من رأس Accept-Language
   * @returns {string} - رمز اللغة بتنسيق ISO 639-1 (مثل 'ar', 'en', إلخ)
   */
  getBrowserLanguage() {
    // الحصول على لغة المتصفح
    const browserLang = navigator.language || navigator.userLanguage;
    
    if (!browserLang) {
      return this.defaultLanguage;
    }
    
    // استخراج رمز اللغة الأساسي (مثل 'en' من 'en-US')
    const langCode = browserLang.split('-')[0].toLowerCase();
    
    // التحقق مما إذا كانت اللغة مدعومة
    if (this.supportedLanguages.includes(langCode)) {
      return langCode;
    }
    
    // إرجاع اللغة الافتراضية إذا لم تكن اللغة مدعومة
    return this.defaultLanguage;
  }

  /**
   * ترجمة نص باستخدام واجهة برمجة الترجمة
   * @param {string} text - النص المراد ترجمته
   * @param {string} targetLanguage - اللغة الهدف
   * @param {string} sourceLanguage - لغة المصدر (اختياري)
   * @returns {Promise<string>} - وعد بالنص المترجم
   */
  async translateText(text, targetLanguage, sourceLanguage = null) {
    // لا نحتاج لترجمة إذا كان النص فارغاً أو اللغة الهدف هي نفس لغة المصدر
    if (!text || targetLanguage === sourceLanguage) {
      return text;
    }
    
    // استخدام النص المخزن مؤقتًا إذا كان متاحًا
    const cacheKey = `${text}_${targetLanguage}_${sourceLanguage || 'auto'}`;
    if (this.translationCache[cacheKey]) {
      return this.translationCache[cacheKey];
    }
    
    // إعداد بيانات الطلب
    const data = {
      q: text,
      target: targetLanguage,
      key: this.apiKey
    };
    
    if (sourceLanguage) {
      data.source = sourceLanguage;
    }
    
    try {
      // إرسال طلب الترجمة
      const response = await fetch(`${this.baseUrl}?${new URLSearchParams(data)}`);
      
      if (!response.ok) {
        throw new Error(`خطأ في طلب الترجمة: ${response.status} ${response.statusText}`);
      }
      
      // تحليل الاستجابة
      const result = await response.json();
      const translatedText = result.data.translations[0].translatedText;
      
      // تخزين الترجمة مؤقتًا
      this.translationCache[cacheKey] = translatedText;
      
      return translatedText;
    } catch (error) {
      console.error('خطأ في الترجمة:', error);
      return text;
    }
  }

  /**
   * ترجمة محتوى المدونة
   * @param {Object|Array} content - محتوى المدونة
   * @param {string} targetLanguage - اللغة الهدف
   * @returns {Promise<Object|Array>} - وعد بمحتوى المدونة المترجم
   */
  async translateContent(content, targetLanguage) {
    // لا نحتاج لترجمة إذا كان المحتوى فارغاً أو اللغة الهدف هي الافتراضية
    if (!content || targetLanguage === this.defaultLanguage) {
      return content;
    }
    
    // نسخة من المحتوى للترجمة
    let translatedContent;
    
    // ترجمة الحقول النصية
    if (typeof content === 'object' && content !== null) {
      if (Array.isArray(content)) {
        // إذا كان المحتوى مصفوفة، ترجمة كل عنصر
        translatedContent = [];
        for (const item of content) {
          translatedContent.push(await this.translateContent(item, targetLanguage));
        }
      } else {
        // إذا كان المحتوى كائناً، ترجمة الحقول النصية
        translatedContent = { ...content };
        for (const [key, value] of Object.entries(content)) {
          if (['title', 'subtitle', 'summary', 'content', 'description'].includes(key) && typeof value === 'string') {
            translatedContent[key] = await this.translateText(value, targetLanguage, this.defaultLanguage);
          } else if (typeof value === 'object' && value !== null) {
            translatedContent[key] = await this.translateContent(value, targetLanguage);
          }
        }
      }
    } else {
      // إذا كان المحتوى نصاً، ترجمته مباشرة
      translatedContent = content;
    }
    
    return translatedContent;
  }

  /**
   * تعيين لغة المستخدم
   * @param {string} language - رمز اللغة
   * @returns {boolean} - نجاح العملية
   */
  setUserLanguage(language) {
    if (!language || !this.supportedLanguages.includes(language)) {
      return false;
    }
    
    // تخزين اللغة في التخزين المحلي
    localStorage.setItem('user_language', language);
    localStorage.setItem('auto_detect_language', 'false');
    
    return true;
  }

  /**
   * الحصول على لغة المستخدم
   * @returns {string} - رمز اللغة
   */
  getUserLanguage() {
    // التحقق من وجود لغة مخزنة
    const storedLanguage = localStorage.getItem('user_language');
    const autoDetect = localStorage.getItem('auto_detect_language') !== 'false';
    
    if (storedLanguage && !autoDetect) {
      return storedLanguage;
    }
    
    // استخدام لغة المتصفح إذا كان الاكتشاف التلقائي مفعلاً
    return this.getBrowserLanguage();
  }

  /**
   * تفعيل/تعطيل اكتشاف لغة المتصفح التلقائي
   * @param {boolean} enable - تفعيل الاكتشاف التلقائي
   */
  setAutoDetect(enable) {
    localStorage.setItem('auto_detect_language', enable ? 'true' : 'false');
    
    if (enable) {
      // إذا تم تفعيل الاكتشاف التلقائي، استخدام لغة المتصفح
      const browserLanguage = this.getBrowserLanguage();
      localStorage.setItem('user_language', browserLanguage);
    }
  }

  /**
   * الحصول على اسم اللغة من رمزها
   * @param {string} langCode - رمز اللغة
   * @returns {string} - اسم اللغة
   */
  getLanguageName(langCode) {
    const languageNames = {
      'ar': 'العربية',
      'en': 'English',
      'fr': 'Français',
      'es': 'Español',
      'de': 'Deutsch',
      'it': 'Italiano',
      'ru': 'Русский',
      'zh': '中文',
      'ja': '日本語',
      'ko': '한국어'
    };
    
    return languageNames[langCode] || langCode;
  }

  /**
   * التحقق مما إذا كانت اللغة تُكتب من اليمين إلى اليسار
   * @param {string} langCode - رمز اللغة
   * @returns {boolean} - ما إذا كانت اللغة RTL
   */
  isRTL(langCode) {
    const rtlLanguages = ['ar', 'he', 'ur', 'fa'];
    return rtlLanguages.includes(langCode);
  }

  /**
   * تطبيق اتجاه اللغة على عناصر الصفحة
   * @param {string} langCode - رمز اللغة
   */
  applyLanguageDirection(langCode) {
    const isRtl = this.isRTL(langCode);
    document.documentElement.dir = isRtl ? 'rtl' : 'ltr';
    document.documentElement.lang = langCode;
    
    // إضافة/إزالة فئة RTL من عنصر الجسم
    if (isRtl) {
      document.body.classList.add('rtl');
    } else {
      document.body.classList.remove('rtl');
    }
  }
}

// تصدير الفئة للاستخدام في ملفات أخرى
export default TranslationAPI;
