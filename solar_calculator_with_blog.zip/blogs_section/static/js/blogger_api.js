/**
 * واجهة برمجة تطبيقات Blogger
 * توفر هذه الوحدة وظائف للتفاعل مع Blogger API v3
 */

class BloggerAPI {
  /**
   * إنشاء كائن جديد من واجهة برمجة تطبيقات Blogger
   * @param {Object} config - إعدادات التكوين
   */
  constructor(config = {}) {
    this.apiKey = config.apiKey || '';
    this.clientId = config.clientId || '';
    this.clientSecret = config.clientSecret || '';
    this.redirectUri = config.redirectUri || '';
    this.accessToken = null;
    this.blogId = config.blogId || null;
    this.baseUrl = 'https://www.googleapis.com/blogger/v3';
    this.scopes = [
      'https://www.googleapis.com/auth/blogger',
      'https://www.googleapis.com/auth/blogger.readonly'
    ];
  }

  /**
   * المصادقة مع Blogger API
   * @returns {Promise<Object>} - وعد بنتيجة المصادقة
   */
  async authenticate() {
    // التحقق من وجود رمز الوصول في التخزين المحلي
    const storedToken = localStorage.getItem('blogger_access_token');
    const tokenExpiry = localStorage.getItem('blogger_token_expiry');
    
    if (storedToken && tokenExpiry && new Date().getTime() < parseInt(tokenExpiry)) {
      this.accessToken = storedToken;
      return { success: true, accessToken: this.accessToken };
    }
    
    // إذا لم يكن هناك رمز وصول صالح، بدء عملية المصادقة
    const authUrl = `https://accounts.google.com/o/oauth2/auth?` +
      `client_id=${this.clientId}` +
      `&redirect_uri=${encodeURIComponent(this.redirectUri)}` +
      `&scope=${encodeURIComponent(this.scopes.join(' '))}` +
      `&response_type=token`;
    
    // فتح نافذة المصادقة
    const authWindow = window.open(authUrl, '_blank', 'width=600,height=700');
    
    return new Promise((resolve, reject) => {
      // مراقبة تغييرات عنوان URL في النافذة المنبثقة
      const checkRedirect = setInterval(() => {
        try {
          if (authWindow.closed) {
            clearInterval(checkRedirect);
            reject(new Error('تم إغلاق نافذة المصادقة'));
          }
          
          const redirectUrl = authWindow.location.href;
          if (redirectUrl.includes('access_token=')) {
            clearInterval(checkRedirect);
            authWindow.close();
            
            // استخراج رمز الوصول ومدة الصلاحية
            const hashParams = new URLSearchParams(redirectUrl.split('#')[1]);
            const accessToken = hashParams.get('access_token');
            const expiresIn = hashParams.get('expires_in');
            const expiryTime = new Date().getTime() + parseInt(expiresIn) * 1000;
            
            // تخزين رمز الوصول ووقت انتهاء الصلاحية
            localStorage.setItem('blogger_access_token', accessToken);
            localStorage.setItem('blogger_token_expiry', expiryTime.toString());
            
            this.accessToken = accessToken;
            resolve({ success: true, accessToken });
          }
        } catch (e) {
          // تجاهل أخطاء الوصول عبر المجالات
        }
      }, 500);
    });
  }

  /**
   * إجراء طلب إلى Blogger API
   * @param {string} endpoint - نقطة النهاية للطلب
   * @param {Object} options - خيارات الطلب
   * @returns {Promise<Object>} - وعد بنتيجة الطلب
   */
  async makeRequest(endpoint, options = {}) {
    // التأكد من وجود رمز وصول
    if (!this.accessToken) {
      await this.authenticate();
    }
    
    const url = `${this.baseUrl}${endpoint}`;
    const headers = {
      'Authorization': `Bearer ${this.accessToken}`,
      'Content-Type': 'application/json'
    };
    
    const requestOptions = {
      ...options,
      headers
    };
    
    try {
      const response = await fetch(url, requestOptions);
      
      if (!response.ok) {
        // إذا كان الخطأ بسبب انتهاء صلاحية رمز الوصول، إعادة المصادقة وإعادة المحاولة
        if (response.status === 401) {
          localStorage.removeItem('blogger_access_token');
          localStorage.removeItem('blogger_token_expiry');
          await this.authenticate();
          return this.makeRequest(endpoint, options);
        }
        
        throw new Error(`خطأ في طلب Blogger API: ${response.status} ${response.statusText}`);
      }
      
      return await response.json();
    } catch (error) {
      console.error('خطأ في طلب Blogger API:', error);
      throw error;
    }
  }

  /**
   * الحصول على معلومات المدونة
   * @param {string} blogId - معرف المدونة (اختياري، يستخدم المعرف المخزن إذا لم يتم تحديده)
   * @returns {Promise<Object>} - وعد بمعلومات المدونة
   */
  async getBlogInfo(blogId = null) {
    const targetBlogId = blogId || this.blogId;
    if (!targetBlogId) {
      throw new Error('معرف المدونة مطلوب');
    }
    
    return this.makeRequest(`/blogs/${targetBlogId}`);
  }

  /**
   * الحصول على قائمة المدونات للمستخدم المصادق
   * @returns {Promise<Object>} - وعد بقائمة المدونات
   */
  async listBlogs() {
    return this.makeRequest('/users/self/blogs');
  }

  /**
   * الحصول على قائمة المنشورات
   * @param {string} blogId - معرف المدونة (اختياري، يستخدم المعرف المخزن إذا لم يتم تحديده)
   * @param {Object} params - معلمات إضافية للطلب
   * @returns {Promise<Object>} - وعد بقائمة المنشورات
   */
  async listPosts(blogId = null, params = {}) {
    const targetBlogId = blogId || this.blogId;
    if (!targetBlogId) {
      throw new Error('معرف المدونة مطلوب');
    }
    
    // بناء سلسلة الاستعلام
    const queryParams = new URLSearchParams();
    for (const [key, value] of Object.entries(params)) {
      queryParams.append(key, value);
    }
    
    const queryString = queryParams.toString() ? `?${queryParams.toString()}` : '';
    return this.makeRequest(`/blogs/${targetBlogId}/posts${queryString}`);
  }

  /**
   * الحصول على منشور محدد
   * @param {string} blogId - معرف المدونة (اختياري، يستخدم المعرف المخزن إذا لم يتم تحديده)
   * @param {string} postId - معرف المنشور
   * @returns {Promise<Object>} - وعد بمعلومات المنشور
   */
  async getPost(blogId = null, postId) {
    const targetBlogId = blogId || this.blogId;
    if (!targetBlogId) {
      throw new Error('معرف المدونة مطلوب');
    }
    
    if (!postId) {
      throw new Error('معرف المنشور مطلوب');
    }
    
    return this.makeRequest(`/blogs/${targetBlogId}/posts/${postId}`);
  }

  /**
   * إنشاء منشور جديد
   * @param {string} blogId - معرف المدونة (اختياري، يستخدم المعرف المخزن إذا لم يتم تحديده)
   * @param {string} title - عنوان المنشور
   * @param {string} content - محتوى المنشور
   * @param {Object} options - خيارات إضافية للمنشور
   * @returns {Promise<Object>} - وعد بمعلومات المنشور الجديد
   */
  async createPost(blogId = null, title, content, options = {}) {
    const targetBlogId = blogId || this.blogId;
    if (!targetBlogId) {
      throw new Error('معرف المدونة مطلوب');
    }
    
    const postData = {
      kind: 'blogger#post',
      title,
      content,
      ...options
    };
    
    return this.makeRequest(`/blogs/${targetBlogId}/posts`, {
      method: 'POST',
      body: JSON.stringify(postData)
    });
  }

  /**
   * تحديث منشور موجود
   * @param {string} blogId - معرف المدونة (اختياري، يستخدم المعرف المخزن إذا لم يتم تحديده)
   * @param {string} postId - معرف المنشور
   * @param {Object} postData - بيانات المنشور المحدثة
   * @returns {Promise<Object>} - وعد بمعلومات المنشور المحدث
   */
  async updatePost(blogId = null, postId, postData) {
    const targetBlogId = blogId || this.blogId;
    if (!targetBlogId) {
      throw new Error('معرف المدونة مطلوب');
    }
    
    if (!postId) {
      throw new Error('معرف المنشور مطلوب');
    }
    
    return this.makeRequest(`/blogs/${targetBlogId}/posts/${postId}`, {
      method: 'PUT',
      body: JSON.stringify(postData)
    });
  }

  /**
   * حذف منشور
   * @param {string} blogId - معرف المدونة (اختياري، يستخدم المعرف المخزن إذا لم يتم تحديده)
   * @param {string} postId - معرف المنشور
   * @returns {Promise<Object>} - وعد بنتيجة الحذف
   */
  async deletePost(blogId = null, postId) {
    const targetBlogId = blogId || this.blogId;
    if (!targetBlogId) {
      throw new Error('معرف المدونة مطلوب');
    }
    
    if (!postId) {
      throw new Error('معرف المنشور مطلوب');
    }
    
    return this.makeRequest(`/blogs/${targetBlogId}/posts/${postId}`, {
      method: 'DELETE'
    });
  }

  /**
   * البحث في المنشورات
   * @param {string} blogId - معرف المدونة (اختياري، يستخدم المعرف المخزن إذا لم يتم تحديده)
   * @param {string} query - نص البحث
   * @returns {Promise<Object>} - وعد بنتائج البحث
   */
  async searchPosts(blogId = null, query) {
    const targetBlogId = blogId || this.blogId;
    if (!targetBlogId) {
      throw new Error('معرف المدونة مطلوب');
    }
    
    if (!query) {
      throw new Error('نص البحث مطلوب');
    }
    
    return this.makeRequest(`/blogs/${targetBlogId}/posts/search?q=${encodeURIComponent(query)}`);
  }

  /**
   * الحصول على قائمة التعليقات لمنشور
   * @param {string} blogId - معرف المدونة (اختياري، يستخدم المعرف المخزن إذا لم يتم تحديده)
   * @param {string} postId - معرف المنشور
   * @param {Object} params - معلمات إضافية للطلب
   * @returns {Promise<Object>} - وعد بقائمة التعليقات
   */
  async listComments(blogId = null, postId, params = {}) {
    const targetBlogId = blogId || this.blogId;
    if (!targetBlogId) {
      throw new Error('معرف المدونة مطلوب');
    }
    
    if (!postId) {
      throw new Error('معرف المنشور مطلوب');
    }
    
    // بناء سلسلة الاستعلام
    const queryParams = new URLSearchParams();
    for (const [key, value] of Object.entries(params)) {
      queryParams.append(key, value);
    }
    
    const queryString = queryParams.toString() ? `?${queryParams.toString()}` : '';
    return this.makeRequest(`/blogs/${targetBlogId}/posts/${postId}/comments${queryString}`);
  }

  /**
   * إنشاء تعليق جديد
   * @param {string} blogId - معرف المدونة (اختياري، يستخدم المعرف المخزن إذا لم يتم تحديده)
   * @param {string} postId - معرف المنشور
   * @param {string} content - محتوى التعليق
   * @returns {Promise<Object>} - وعد بمعلومات التعليق الجديد
   */
  async createComment(blogId = null, postId, content) {
    const targetBlogId = blogId || this.blogId;
    if (!targetBlogId) {
      throw new Error('معرف المدونة مطلوب');
    }
    
    if (!postId) {
      throw new Error('معرف المنشور مطلوب');
    }
    
    const commentData = {
      kind: 'blogger#comment',
      content
    };
    
    return this.makeRequest(`/blogs/${targetBlogId}/posts/${postId}/comments`, {
      method: 'POST',
      body: JSON.stringify(commentData)
    });
  }

  /**
   * حذف تعليق
   * @param {string} blogId - معرف المدونة (اختياري، يستخدم المعرف المخزن إذا لم يتم تحديده)
   * @param {string} postId - معرف المنشور
   * @param {string} commentId - معرف التعليق
   * @returns {Promise<Object>} - وعد بنتيجة الحذف
   */
  async deleteComment(blogId = null, postId, commentId) {
    const targetBlogId = blogId || this.blogId;
    if (!targetBlogId) {
      throw new Error('معرف المدونة مطلوب');
    }
    
    if (!postId) {
      throw new Error('معرف المنشور مطلوب');
    }
    
    if (!commentId) {
      throw new Error('معرف التعليق مطلوب');
    }
    
    return this.makeRequest(`/blogs/${targetBlogId}/posts/${postId}/comments/${commentId}`, {
      method: 'DELETE'
    });
  }
}

// تصدير الفئة للاستخدام في ملفات أخرى
export default BloggerAPI;
