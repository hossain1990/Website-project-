/**
 * واجهة برمجة تطبيقات Google Search Console
 * توفر هذه الوحدة وظائف للتفاعل مع Google Search Console API
 */

class SearchConsoleAPI {
  /**
   * إنشاء كائن جديد من واجهة برمجة تطبيقات Search Console
   * @param {Object} config - إعدادات التكوين
   */
  constructor(config = {}) {
    this.apiKey = config.apiKey || '';
    this.clientId = config.clientId || '';
    this.clientSecret = config.clientSecret || '';
    this.redirectUri = config.redirectUri || '';
    this.accessToken = null;
    this.siteUrl = config.siteUrl || null;
    this.baseUrl = 'https://www.googleapis.com/webmasters/v3';
    this.scopes = [
      'https://www.googleapis.com/auth/webmasters',
      'https://www.googleapis.com/auth/webmasters.readonly'
    ];
  }

  /**
   * المصادقة مع Search Console API
   * @returns {Promise<Object>} - وعد بنتيجة المصادقة
   */
  async authenticate() {
    // التحقق من وجود رمز الوصول في التخزين المحلي
    const storedToken = localStorage.getItem('search_console_access_token');
    const tokenExpiry = localStorage.getItem('search_console_token_expiry');
    
    if (storedToken && tokenExpiry && new Date().getTime() < parseInt(tokenExpiry)) {
      this.accessToken = storedToken;
      return { success: true, accessToken: this.accessToken };
    }
    
    // إذا لم يكن هناك رمز وصول صالح، بدء عملية المصادقة
    const authUrl = `https://accounts.google.com/o/oauth2/auth?` +
      `client_id=${this.clientId}` +
      `&redirect_uri=${encodeURIComponent(this.redirectUri)}` +
      `&scope=${encodeURIComponent(this.scopes.join(' '))}` +
      `&response_type=token`;
    
    // فتح نافذة المصادقة
    const authWindow = window.open(authUrl, '_blank', 'width=600,height=700');
    
    return new Promise((resolve, reject) => {
      // مراقبة تغييرات عنوان URL في النافذة المنبثقة
      const checkRedirect = setInterval(() => {
        try {
          if (authWindow.closed) {
            clearInterval(checkRedirect);
            reject(new Error('تم إغلاق نافذة المصادقة'));
          }
          
          const redirectUrl = authWindow.location.href;
          if (redirectUrl.includes('access_token=')) {
            clearInterval(checkRedirect);
            authWindow.close();
            
            // استخراج رمز الوصول ومدة الصلاحية
            const hashParams = new URLSearchParams(redirectUrl.split('#')[1]);
            const accessToken = hashParams.get('access_token');
            const expiresIn = hashParams.get('expires_in');
            const expiryTime = new Date().getTime() + parseInt(expiresIn) * 1000;
            
            // تخزين رمز الوصول ووقت انتهاء الصلاحية
            localStorage.setItem('search_console_access_token', accessToken);
            localStorage.setItem('search_console_token_expiry', expiryTime.toString());
            
            this.accessToken = accessToken;
            resolve({ success: true, accessToken });
          }
        } catch (e) {
          // تجاهل أخطاء الوصول عبر المجالات
        }
      }, 500);
    });
  }

  /**
   * إجراء طلب إلى Search Console API
   * @param {string} endpoint - نقطة النهاية للطلب
   * @param {Object} options - خيارات الطلب
   * @returns {Promise<Object>} - وعد بنتيجة الطلب
   */
  async makeRequest(endpoint, options = {}) {
    // التأكد من وجود رمز وصول
    if (!this.accessToken) {
      await this.authenticate();
    }
    
    const url = `${this.baseUrl}${endpoint}`;
    const headers = {
      'Authorization': `Bearer ${this.accessToken}`,
      'Content-Type': 'application/json'
    };
    
    const requestOptions = {
      ...options,
      headers
    };
    
    try {
      const response = await fetch(url, requestOptions);
      
      if (!response.ok) {
        // إذا كان الخطأ بسبب انتهاء صلاحية رمز الوصول، إعادة المصادقة وإعادة المحاولة
        if (response.status === 401) {
          localStorage.removeItem('search_console_access_token');
          localStorage.removeItem('search_console_token_expiry');
          await this.authenticate();
          return this.makeRequest(endpoint, options);
        }
        
        throw new Error(`خطأ في طلب Search Console API: ${response.status} ${response.statusText}`);
      }
      
      return await response.json();
    } catch (error) {
      console.error('خطأ في طلب Search Console API:', error);
      throw error;
    }
  }

  /**
   * الحصول على قائمة المواقع
   * @returns {Promise<Object>} - وعد بقائمة المواقع
   */
  async listSites() {
    return this.makeRequest('/sites');
  }

  /**
   * الحصول على معلومات موقع محدد
   * @param {string} siteUrl - عنوان URL للموقع (اختياري، يستخدم العنوان المخزن إذا لم يتم تحديده)
   * @returns {Promise<Object>} - وعد بمعلومات الموقع
   */
  async getSiteInfo(siteUrl = null) {
    const targetSiteUrl = siteUrl || this.siteUrl;
    
    if (!targetSiteUrl) {
      throw new Error('عنوان URL للموقع مطلوب');
    }
    
    return this.makeRequest(`/sites/${encodeURIComponent(targetSiteUrl)}`);
  }

  /**
   * الحصول على أهم استعلامات البحث
   * @param {string} startDate - تاريخ البداية (YYYY-MM-DD)
   * @param {string} endDate - تاريخ النهاية (YYYY-MM-DD)
   * @param {string} siteUrl - عنوان URL للموقع (اختياري، يستخدم العنوان المخزن إذا لم يتم تحديده)
   * @param {number} rowLimit - عدد النتائج المطلوبة
   * @returns {Promise<Object>} - وعد بنتائج الاستعلامات
   */
  async getTopQueries(startDate, endDate, siteUrl = null, rowLimit = 10) {
    const targetSiteUrl = siteUrl || this.siteUrl;
    
    if (!targetSiteUrl) {
      throw new Error('عنوان URL للموقع مطلوب');
    }
    
    if (!startDate || !endDate) {
      throw new Error('تاريخ البداية والنهاية مطلوبان');
    }
    
    const queryData = {
      startDate,
      endDate,
      dimensions: ['query'],
      rowLimit
    };
    
    return this.makeRequest(`/sites/${encodeURIComponent(targetSiteUrl)}/searchAnalytics/query`, {
      method: 'POST',
      body: JSON.stringify(queryData)
    });
  }

  /**
   * الحصول على أهم الصفحات
   * @param {string} startDate - تاريخ البداية (YYYY-MM-DD)
   * @param {string} endDate - تاريخ النهاية (YYYY-MM-DD)
   * @param {string} siteUrl - عنوان URL للموقع (اختياري، يستخدم العنوان المخزن إذا لم يتم تحديده)
   * @param {number} rowLimit - عدد النتائج المطلوبة
   * @returns {Promise<Object>} - وعد بنتائج الصفحات
   */
  async getTopPages(startDate, endDate, siteUrl = null, rowLimit = 10) {
    const targetSiteUrl = siteUrl || this.siteUrl;
    
    if (!targetSiteUrl) {
      throw new Error('عنوان URL للموقع مطلوب');
    }
    
    if (!startDate || !endDate) {
      throw new Error('تاريخ البداية والنهاية مطلوبان');
    }
    
    const queryData = {
      startDate,
      endDate,
      dimensions: ['page'],
      rowLimit
    };
    
    return this.makeRequest(`/sites/${encodeURIComponent(targetSiteUrl)}/searchAnalytics/query`, {
      method: 'POST',
      body: JSON.stringify(queryData)
    });
  }

  /**
   * الحصول على تحليلات البحث مع تصفية حسب الأبعاد
   * @param {string} startDate - تاريخ البداية (YYYY-MM-DD)
   * @param {string} endDate - تاريخ النهاية (YYYY-MM-DD)
   * @param {string} siteUrl - عنوان URL للموقع (اختياري، يستخدم العنوان المخزن إذا لم يتم تحديده)
   * @param {Array} dimensions - الأبعاد المطلوبة (query, page, country, device, date)
   * @param {number} rowLimit - عدد النتائج المطلوبة
   * @returns {Promise<Object>} - وعد بنتائج التحليلات
   */
  async getSearchAnalytics(startDate, endDate, siteUrl = null, dimensions = ['query'], rowLimit = 10) {
    const targetSiteUrl = siteUrl || this.siteUrl;
    
    if (!targetSiteUrl) {
      throw new Error('عنوان URL للموقع مطلوب');
    }
    
    if (!startDate || !endDate) {
      throw new Error('تاريخ البداية والنهاية مطلوبان');
    }
    
    const queryData = {
      startDate,
      endDate,
      dimensions,
      rowLimit
    };
    
    return this.makeRequest(`/sites/${encodeURIComponent(targetSiteUrl)}/searchAnalytics/query`, {
      method: 'POST',
      body: JSON.stringify(queryData)
    });
  }

  /**
   * الحصول على قائمة خرائط الموقع
   * @param {string} siteUrl - عنوان URL للموقع (اختياري، يستخدم العنوان المخزن إذا لم يتم تحديده)
   * @returns {Promise<Object>} - وعد بقائمة خرائط الموقع
   */
  async listSitemaps(siteUrl = null) {
    const targetSiteUrl = siteUrl || this.siteUrl;
    
    if (!targetSiteUrl) {
      throw new Error('عنوان URL للموقع مطلوب');
    }
    
    return this.makeRequest(`/sites/${encodeURIComponent(targetSiteUrl)}/sitemaps`);
  }

  /**
   * إرسال خريطة موقع جديدة
   * @param {string} sitemapUrl - عنوان URL لخريطة الموقع
   * @param {string} siteUrl - عنوان URL للموقع (اختياري، يستخدم العنوان المخزن إذا لم يتم تحديده)
   * @returns {Promise<Object>} - وعد بنتيجة الإرسال
   */
  async submitSitemap(sitemapUrl, siteUrl = null) {
    const targetSiteUrl = siteUrl || this.siteUrl;
    
    if (!targetSiteUrl) {
      throw new Error('عنوان URL للموقع مطلوب');
    }
    
    if (!sitemapUrl) {
      throw new Error('عنوان URL لخريطة الموقع مطلوب');
    }
    
    return this.makeRequest(`/sites/${encodeURIComponent(targetSiteUrl)}/sitemaps/${encodeURIComponent(sitemapUrl)}`, {
      method: 'PUT'
    });
  }

  /**
   * حذف خريطة موقع
   * @param {string} sitemapUrl - عنوان URL لخريطة الموقع
   * @param {string} siteUrl - عنوان URL للموقع (اختياري، يستخدم العنوان المخزن إذا لم يتم تحديده)
   * @returns {Promise<Object>} - وعد بنتيجة الحذف
   */
  async deleteSitemap(sitemapUrl, siteUrl = null) {
    const targetSiteUrl = siteUrl || this.siteUrl;
    
    if (!targetSiteUrl) {
      throw new Error('عنوان URL للموقع مطلوب');
    }
    
    if (!sitemapUrl) {
      throw new Error('عنوان URL لخريطة الموقع مطلوب');
    }
    
    return this.makeRequest(`/sites/${encodeURIComponent(targetSiteUrl)}/sitemaps/${encodeURIComponent(sitemapUrl)}`, {
      method: 'DELETE'
    });
  }

  /**
   * فحص عنوان URL
   * @param {string} url - عنوان URL للفحص
   * @returns {Promise<Object>} - وعد بنتيجة الفحص
   */
  async inspectUrl(url) {
    if (!url) {
      throw new Error('عنوان URL للفحص مطلوب');
    }
    
    const inspectData = {
      inspectionUrl: url
    };
    
    return this.makeRequest(`/urlInspection/index`, {
      method: 'POST',
      body: JSON.stringify(inspectData)
    });
  }
}

// تصدير الفئة للاستخدام في ملفات أخرى
export default SearchConsoleAPI;
