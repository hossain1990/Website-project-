"""
اختبار تكامل واجهات برمجة التطبيقات لقسم المدونات
"""

import os
import sys
import unittest
from unittest.mock import MagicMock, patch
import json

# إضافة المسار إلى المشروع
sys.path.append('/home/ubuntu/blogs_section')

# استيراد الوحدات المطلوبة للاختبار
from api.blogger.blogger_api import BloggerAPI
from api.adsense.adsense_api import AdSenseAPI
from api.analytics.analytics_api import AnalyticsAPI
from api.search_console.search_console_api import SearchConsoleAPI

class TestAPIIntegration(unittest.TestCase):
    """اختبار تكامل واجهات برمجة التطبيقات"""
    
    def setUp(self):
        """إعداد بيئة الاختبار"""
        # إنشاء نسخ وهمية من واجهات البرمجة
        self.blogger_api = BloggerAPI()
        self.adsense_api = AdSenseAPI()
        self.analytics_api = AnalyticsAPI()
        self.search_console_api = SearchConsoleAPI()
        
        # تعطيل المصادقة الفعلية للاختبار
        self.blogger_api.authenticate = MagicMock(return_value=MagicMock())
        self.adsense_api.authenticate = MagicMock(return_value=MagicMock())
        self.analytics_api.authenticate = MagicMock(return_value=MagicMock())
        self.search_console_api.authenticate = MagicMock(return_value=MagicMock())
        
        # تهيئة خدمات وهمية
        self.blogger_api.service = MagicMock()
        self.adsense_api.service = MagicMock()
        self.analytics_api.service = MagicMock()
        self.search_console_api.service = MagicMock()
    
    def test_blogger_api_get_blog_info(self):
        """اختبار الحصول على معلومات المدونة"""
        # إعداد البيانات الوهمية
        mock_blog_info = {
            'id': '12345',
            'name': 'مدونة الطاقة الشمسية',
            'description': 'مدونة متخصصة في الطاقة الشمسية والاستدامة',
            'url': 'https://example.com/blog'
        }
        
        # تكوين السلوك الوهمي
        self.blogger_api.service.blogs().get().execute = MagicMock(return_value=mock_blog_info)
        
        # تنفيذ الاختبار
        result = self.blogger_api.get_blog_info('12345')
        
        # التحقق من النتائج
        self.assertEqual(result, mock_blog_info)
        self.assertEqual(result['name'], 'مدونة الطاقة الشمسية')
    
    def test_blogger_api_list_posts(self):
        """اختبار الحصول على قائمة المنشورات"""
        # إعداد البيانات الوهمية
        mock_posts = {
            'items': [
                {
                    'id': 'post1',
                    'title': 'كيف تحول منزلك بالكامل للاعتماد على الطاقة الشمسية',
                    'content': 'محتوى المنشور الأول',
                    'published': '2025-04-15T10:00:00Z'
                },
                {
                    'id': 'post2',
                    'title': 'أفضل 5 ألواح شمسية لعام 2025',
                    'content': 'محتوى المنشور الثاني',
                    'published': '2025-04-12T10:00:00Z'
                }
            ]
        }
        
        # تكوين السلوك الوهمي
        self.blogger_api.service.posts().list().execute = MagicMock(return_value=mock_posts)
        
        # تنفيذ الاختبار
        result = self.blogger_api.list_posts('12345')
        
        # التحقق من النتائج
        self.assertEqual(len(result['items']), 2)
        self.assertEqual(result['items'][0]['title'], 'كيف تحول منزلك بالكامل للاعتماد على الطاقة الشمسية')
    
    def test_blogger_api_create_post(self):
        """اختبار إنشاء منشور جديد"""
        # إعداد البيانات الوهمية
        mock_post = {
            'id': 'new_post',
            'title': 'منشور جديد',
            'content': 'محتوى المنشور الجديد',
            'published': '2025-04-15T12:00:00Z'
        }
        
        # تكوين السلوك الوهمي
        self.blogger_api.service.posts().insert().execute = MagicMock(return_value=mock_post)
        
        # تنفيذ الاختبار
        result = self.blogger_api.create_post('12345', 'منشور جديد', 'محتوى المنشور الجديد')
        
        # التحقق من النتائج
        self.assertEqual(result['title'], 'منشور جديد')
        self.assertEqual(result['id'], 'new_post')
    
    def test_adsense_api_get_account_info(self):
        """اختبار الحصول على معلومات حساب AdSense"""
        # إعداد البيانات الوهمية
        mock_account_info = {
            'name': 'accounts/123456',
            'displayName': 'حساب AdSense',
            'createTime': '2023-01-01T00:00:00Z',
            'state': 'ACTIVE'
        }
        
        # تكوين السلوك الوهمي
        self.adsense_api.service.accounts().get().execute = MagicMock(return_value=mock_account_info)
        
        # تنفيذ الاختبار
        result = self.adsense_api.get_account_info()
        
        # التحقق من النتائج
        self.assertEqual(result['displayName'], 'حساب AdSense')
        self.assertEqual(result['state'], 'ACTIVE')
    
    def test_adsense_api_get_account_earnings(self):
        """اختبار الحصول على تقرير أرباح AdSense"""
        # إعداد البيانات الوهمية
        mock_earnings = {
            'rows': [
                {
                    'cells': [
                        {'value': 100.50},  # الأرباح المقدرة
                        {'value': 5000},    # المشاهدات
                        {'value': 10000},   # الظهور
                        {'value': 200}      # النقرات
                    ]
                }
            ]
        }
        
        # تكوين السلوك الوهمي
        self.adsense_api.service.accounts().reports().generate().execute = MagicMock(return_value=mock_earnings)
        
        # تنفيذ الاختبار
        result = self.adsense_api.get_account_earnings('2025-04-01', '2025-04-15')
        
        # التحقق من النتائج
        self.assertEqual(result['rows'][0]['cells'][0]['value'], 100.50)
        self.assertEqual(result['rows'][0]['cells'][1]['value'], 5000)
    
    def test_analytics_api_run_report(self):
        """اختبار تشغيل تقرير Google Analytics"""
        # إعداد البيانات الوهمية
        mock_report = {
            'rows': [
                {
                    'dimensionValues': [{'value': '2025-04-15'}],
                    'metricValues': [
                        {'value': '100'},  # المستخدمين النشطين
                        {'value': '500'},  # مشاهدات الصفحة
                        {'value': '200'},  # الجلسات
                        {'value': '120'}   # متوسط مدة الجلسة
                    ]
                }
            ]
        }
        
        # تكوين السلوك الوهمي
        self.analytics_api.service.properties().runReport().execute = MagicMock(return_value=mock_report)
        
        # تنفيذ الاختبار
        result = self.analytics_api.run_report('2025-04-01', '2025-04-15')
        
        # التحقق من النتائج
        self.assertEqual(result['rows'][0]['dimensionValues'][0]['value'], '2025-04-15')
        self.assertEqual(result['rows'][0]['metricValues'][0]['value'], '100')
    
    def test_search_console_api_get_top_queries(self):
        """اختبار الحصول على أهم استعلامات البحث"""
        # إعداد البيانات الوهمية
        mock_queries = {
            'rows': [
                {
                    'keys': ['الطاقة الشمسية'],
                    'clicks': 100,
                    'impressions': 1000,
                    'ctr': 0.1,
                    'position': 2.5
                },
                {
                    'keys': ['ألواح شمسية'],
                    'clicks': 80,
                    'impressions': 800,
                    'ctr': 0.1,
                    'position': 3.0
                }
            ]
        }
        
        # تكوين السلوك الوهمي
        self.search_console_api.service.searchanalytics().query().execute = MagicMock(return_value=mock_queries)
        
        # تنفيذ الاختبار
        result = self.search_console_api.get_top_queries('2025-04-01', '2025-04-15')
        
        # التحقق من النتائج
        self.assertEqual(len(result['rows']), 2)
        self.assertEqual(result['rows'][0]['keys'][0], 'الطاقة الشمسية')
        self.assertEqual(result['rows'][0]['clicks'], 100)

if __name__ == '__main__':
    unittest.main()
