#!/bin/bash

# إنشاء ملف __init__.py في مجلد الاختبارات
touch /home/ubuntu/blogs_section/tests/__init__.py

# إنشاء ملف __init__.py في مجلدات API
mkdir -p /home/ubuntu/blogs_section/api/blogger
mkdir -p /home/ubuntu/blogs_section/api/adsense
mkdir -p /home/ubuntu/blogs_section/api/analytics
mkdir -p /home/ubuntu/blogs_section/api/search_console
mkdir -p /home/ubuntu/blogs_section/config

touch /home/ubuntu/blogs_section/api/__init__.py
touch /home/ubuntu/blogs_section/api/blogger/__init__.py
touch /home/ubuntu/blogs_section/api/adsense/__init__.py
touch /home/ubuntu/blogs_section/api/analytics/__init__.py
touch /home/ubuntu/blogs_section/api/search_console/__init__.py
touch /home/ubuntu/blogs_section/config/__init__.py

# تشغيل اختبارات تكامل واجهات البرمجة
echo "تشغيل اختبارات تكامل واجهات البرمجة..."
cd /home/ubuntu/blogs_section
python3 -m unittest tests/test_api_integration.py

# تشغيل اختبارات تكامل واجهة المستخدم
echo "تشغيل اختبارات تكامل واجهة المستخدم..."
cd /home/ubuntu/blogs_section
python3 -m unittest tests/test_ui_integration.py
