/**
 * واجهة برمجة تطبيقات Google Analytics
 * توفر هذه الوحدة وظائف للتفاعل مع Google Analytics Data API v1
 */

class AnalyticsAPI {
  /**
   * إنشاء كائن جديد من واجهة برمجة تطبيقات Google Analytics
   * @param {Object} config - إعدادات التكوين
   */
  constructor(config = {}) {
    this.apiKey = config.apiKey || '';
    this.clientId = config.clientId || '';
    this.clientSecret = config.clientSecret || '';
    this.redirectUri = config.redirectUri || '';
    this.accessToken = null;
    this.propertyId = config.propertyId || null;
    this.baseUrl = 'https://analyticsdata.googleapis.com/v1beta';
    this.scopes = [
      'https://www.googleapis.com/auth/analytics',
      'https://www.googleapis.com/auth/analytics.readonly'
    ];
  }

  /**
   * المصادقة مع Google Analytics API
   * @returns {Promise<Object>} - وعد بنتيجة المصادقة
   */
  async authenticate() {
    // التحقق من وجود رمز الوصول في التخزين المحلي
    const storedToken = localStorage.getItem('analytics_access_token');
    const tokenExpiry = localStorage.getItem('analytics_token_expiry');
    
    if (storedToken && tokenExpiry && new Date().getTime() < parseInt(tokenExpiry)) {
      this.accessToken = storedToken;
      return { success: true, accessToken: this.accessToken };
    }
    
    // إذا لم يكن هناك رمز وصول صالح، بدء عملية المصادقة
    const authUrl = `https://accounts.google.com/o/oauth2/auth?` +
      `client_id=${this.clientId}` +
      `&redirect_uri=${encodeURIComponent(this.redirectUri)}` +
      `&scope=${encodeURIComponent(this.scopes.join(' '))}` +
      `&response_type=token`;
    
    // فتح نافذة المصادقة
    const authWindow = window.open(authUrl, '_blank', 'width=600,height=700');
    
    return new Promise((resolve, reject) => {
      // مراقبة تغييرات عنوان URL في النافذة المنبثقة
      const checkRedirect = setInterval(() => {
        try {
          if (authWindow.closed) {
            clearInterval(checkRedirect);
            reject(new Error('تم إغلاق نافذة المصادقة'));
          }
          
          const redirectUrl = authWindow.location.href;
          if (redirectUrl.includes('access_token=')) {
            clearInterval(checkRedirect);
            authWindow.close();
            
            // استخراج رمز الوصول ومدة الصلاحية
            const hashParams = new URLSearchParams(redirectUrl.split('#')[1]);
            const accessToken = hashParams.get('access_token');
            const expiresIn = hashParams.get('expires_in');
            const expiryTime = new Date().getTime() + parseInt(expiresIn) * 1000;
            
            // تخزين رمز الوصول ووقت انتهاء الصلاحية
            localStorage.setItem('analytics_access_token', accessToken);
            localStorage.setItem('analytics_token_expiry', expiryTime.toString());
            
            this.accessToken = accessToken;
            resolve({ success: true, accessToken });
          }
        } catch (e) {
          // تجاهل أخطاء الوصول عبر المجالات
        }
      }, 500);
    });
  }

  /**
   * إجراء طلب إلى Google Analytics API
   * @param {string} endpoint - نقطة النهاية للطلب
   * @param {Object} options - خيارات الطلب
   * @returns {Promise<Object>} - وعد بنتيجة الطلب
   */
  async makeRequest(endpoint, options = {}) {
    // التأكد من وجود رمز وصول
    if (!this.accessToken) {
      await this.authenticate();
    }
    
    const url = `${this.baseUrl}${endpoint}`;
    const headers = {
      'Authorization': `Bearer ${this.accessToken}`,
      'Content-Type': 'application/json'
    };
    
    const requestOptions = {
      ...options,
      headers
    };
    
    try {
      const response = await fetch(url, requestOptions);
      
      if (!response.ok) {
        // إذا كان الخطأ بسبب انتهاء صلاحية رمز الوصول، إعادة المصادقة وإعادة المحاولة
        if (response.status === 401) {
          localStorage.removeItem('analytics_access_token');
          localStorage.removeItem('analytics_token_expiry');
          await this.authenticate();
          return this.makeRequest(endpoint, options);
        }
        
        throw new Error(`خطأ في طلب Google Analytics API: ${response.status} ${response.statusText}`);
      }
      
      return await response.json();
    } catch (error) {
      console.error('خطأ في طلب Google Analytics API:', error);
      throw error;
    }
  }

  /**
   * تشغيل تقرير Google Analytics
   * @param {string} startDate - تاريخ البداية (YYYY-MM-DD)
   * @param {string} endDate - تاريخ النهاية (YYYY-MM-DD)
   * @param {string} propertyId - معرف الخاصية (اختياري، يستخدم المعرف المخزن إذا لم يتم تحديده)
   * @param {Array} metrics - المقاييس المطلوبة
   * @param {Array} dimensions - الأبعاد المطلوبة
   * @returns {Promise<Object>} - وعد بنتائج التقرير
   */
  async runReport(startDate, endDate, propertyId = null, metrics = ['activeUsers', 'screenPageViews', 'sessions', 'averageSessionDuration'], dimensions = ['date']) {
    const targetPropertyId = propertyId || this.propertyId;
    
    if (!targetPropertyId) {
      throw new Error('معرف الخاصية مطلوب');
    }
    
    if (!startDate || !endDate) {
      throw new Error('تاريخ البداية والنهاية مطلوبان');
    }
    
    const reportData = {
      dateRanges: [
        {
          startDate,
          endDate
        }
      ],
      metrics: metrics.map(metric => ({ name: metric })),
      dimensions: dimensions.map(dimension => ({ name: dimension }))
    };
    
    return this.makeRequest(`/properties/${targetPropertyId}:runReport`, {
      method: 'POST',
      body: JSON.stringify(reportData)
    });
  }

  /**
   * الحصول على تقرير الصفحات الأكثر مشاهدة
   * @param {string} startDate - تاريخ البداية (YYYY-MM-DD)
   * @param {string} endDate - تاريخ النهاية (YYYY-MM-DD)
   * @param {string} propertyId - معرف الخاصية (اختياري، يستخدم المعرف المخزن إذا لم يتم تحديده)
   * @param {number} limit - عدد النتائج المطلوبة
   * @returns {Promise<Object>} - وعد بنتائج التقرير
   */
  async getTopPages(startDate, endDate, propertyId = null, limit = 10) {
    const targetPropertyId = propertyId || this.propertyId;
    
    if (!targetPropertyId) {
      throw new Error('معرف الخاصية مطلوب');
    }
    
    if (!startDate || !endDate) {
      throw new Error('تاريخ البداية والنهاية مطلوبان');
    }
    
    const reportData = {
      dateRanges: [
        {
          startDate,
          endDate
        }
      ],
      metrics: [
        { name: 'screenPageViews' }
      ],
      dimensions: [
        { name: 'pagePath' },
        { name: 'pageTitle' }
      ],
      limit,
      orderBys: [
        {
          metric: { metricName: 'screenPageViews' },
          desc: true
        }
      ]
    };
    
    return this.makeRequest(`/properties/${targetPropertyId}:runReport`, {
      method: 'POST',
      body: JSON.stringify(reportData)
    });
  }

  /**
   * الحصول على تقرير مصادر حركة المرور
   * @param {string} startDate - تاريخ البداية (YYYY-MM-DD)
   * @param {string} endDate - تاريخ النهاية (YYYY-MM-DD)
   * @param {string} propertyId - معرف الخاصية (اختياري، يستخدم المعرف المخزن إذا لم يتم تحديده)
   * @param {number} limit - عدد النتائج المطلوبة
   * @returns {Promise<Object>} - وعد بنتائج التقرير
   */
  async getTrafficSources(startDate, endDate, propertyId = null, limit = 10) {
    const targetPropertyId = propertyId || this.propertyId;
    
    if (!targetPropertyId) {
      throw new Error('معرف الخاصية مطلوب');
    }
    
    if (!startDate || !endDate) {
      throw new Error('تاريخ البداية والنهاية مطلوبان');
    }
    
    const reportData = {
      dateRanges: [
        {
          startDate,
          endDate
        }
      ],
      metrics: [
        { name: 'sessions' },
        { name: 'activeUsers' }
      ],
      dimensions: [
        { name: 'sessionSource' },
        { name: 'sessionMedium' }
      ],
      limit,
      orderBys: [
        {
          metric: { metricName: 'sessions' },
          desc: true
        }
      ]
    };
    
    return this.makeRequest(`/properties/${targetPropertyId}:runReport`, {
      method: 'POST',
      body: JSON.stringify(reportData)
    });
  }

  /**
   * الحصول على تقرير بيانات المستخدمين الديموغرافية
   * @param {string} startDate - تاريخ البداية (YYYY-MM-DD)
   * @param {string} endDate - تاريخ النهاية (YYYY-MM-DD)
   * @param {string} propertyId - معرف الخاصية (اختياري، يستخدم المعرف المخزن إذا لم يتم تحديده)
   * @returns {Promise<Object>} - وعد بنتائج التقرير
   */
  async getUserDemographics(startDate, endDate, propertyId = null) {
    const targetPropertyId = propertyId || this.propertyId;
    
    if (!targetPropertyId) {
      throw new Error('معرف الخاصية مطلوب');
    }
    
    if (!startDate || !endDate) {
      throw new Error('تاريخ البداية والنهاية مطلوبان');
    }
    
    const reportData = {
      dateRanges: [
        {
          startDate,
          endDate
        }
      ],
      metrics: [
        { name: 'activeUsers' }
      ],
      dimensions: [
        { name: 'country' },
        { name: 'city' },
        { name: 'language' }
      ],
      orderBys: [
        {
          metric: { metricName: 'activeUsers' },
          desc: true
        }
      ]
    };
    
    return this.makeRequest(`/properties/${targetPropertyId}:runReport`, {
      method: 'POST',
      body: JSON.stringify(reportData)
    });
  }

  /**
   * الحصول على تقرير الأجهزة المستخدمة
   * @param {string} startDate - تاريخ البداية (YYYY-MM-DD)
   * @param {string} endDate - تاريخ النهاية (YYYY-MM-DD)
   * @param {string} propertyId - معرف الخاصية (اختياري، يستخدم المعرف المخزن إذا لم يتم تحديده)
   * @returns {Promise<Object>} - وعد بنتائج التقرير
   */
  async getDeviceReport(startDate, endDate, propertyId = null) {
    const targetPropertyId = propertyId || this.propertyId;
    
    if (!targetPropertyId) {
      throw new Error('معرف الخاصية مطلوب');
    }
    
    if (!startDate || !endDate) {
      throw new Error('تاريخ البداية والنهاية مطلوبان');
    }
    
    const reportData = {
      dateRanges: [
        {
          startDate,
          endDate
        }
      ],
      metrics: [
        { name: 'activeUsers' },
        { name: 'sessions' },
        { name: 'screenPageViews' }
      ],
      dimensions: [
        { name: 'deviceCategory' },
        { name: 'operatingSystem' },
        { name: 'browser' }
      ],
      orderBys: [
        {
          metric: { metricName: 'activeUsers' },
          desc: true
        }
      ]
    };
    
    return this.makeRequest(`/properties/${targetPropertyId}:runReport`, {
      method: 'POST',
      body: JSON.stringify(reportData)
    });
  }

  /**
   * إنشاء كود تتبع Google Analytics
   * @param {string} measurementId - معرف القياس
   * @returns {string} - كود HTML لتتبع Google Analytics
   */
  createTrackingCode(measurementId) {
    if (!measurementId) {
      throw new Error('معرف القياس مطلوب');
    }
    
    return `
      <!-- Global site tag (gtag.js) - Google Analytics -->
      <script async src="https://www.googletagmanager.com/gtag/js?id=${measurementId}"></script>
      <script>
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());
        gtag('config', '${measurementId}');
      </script>
    `;
  }
}

// تصدير الفئة للاستخدام في ملفات أخرى
export default AnalyticsAPI;
