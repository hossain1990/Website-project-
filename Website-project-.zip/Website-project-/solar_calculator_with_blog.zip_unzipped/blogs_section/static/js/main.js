/**
 * الوظائف الرئيسية لقسم المدونات
 */

// تهيئة محرر المحتوى
function initContentEditor() {
  if (document.getElementById('contentEditor')) {
    // يمكن استبدال هذا بمحرر WYSIWYG مثل TinyMCE أو CKEditor
    console.log('تم تهيئة محرر المحتوى');
  }
}

// التحقق من صحة نموذج المنشور
function validatePostForm() {
  const form = document.getElementById('postForm');
  if (form) {
    form.addEventListener('submit', function(event) {
      const title = document.getElementById('postTitle').value;
      const content = document.getElementById('postContent').value;
      
      if (!title || title.trim() === '') {
        event.preventDefault();
        alert('يرجى إدخال عنوان للمنشور');
        return false;
      }
      
      if (!content || content.trim() === '') {
        event.preventDefault();
        alert('يرجى إدخال محتوى للمنشور');
        return false;
      }
      
      return true;
    });
  }
}

// تهيئة نموذج التعليقات
function initCommentForm() {
  const commentForm = document.getElementById('commentForm');
  if (commentForm) {
    commentForm.addEventListener('submit', function(event) {
      event.preventDefault();
      
      // هنا سيتم إضافة كود للتعامل مع إرسال التعليق عبر API
      alert('تم إرسال التعليق بنجاح وسيظهر بعد المراجعة');
      commentForm.reset();
    });
  }
}

// تحميل المزيد من المنشورات
function loadMorePosts() {
  const loadMoreBtn = document.getElementById('loadMoreBtn');
  if (loadMoreBtn) {
    loadMoreBtn.addEventListener('click', function() {
      // هنا سيتم إضافة كود لتحميل المزيد من المنشورات عبر API
      console.log('جاري تحميل المزيد من المنشورات...');
    });
  }
}

// تأكيد حذف المنشور
function confirmPostDelete() {
  const deleteButtons = document.querySelectorAll('.delete-post-btn');
  if (deleteButtons.length > 0) {
    deleteButtons.forEach(button => {
      button.addEventListener('click', function(event) {
        if (!confirm('هل أنت متأكد من رغبتك في حذف هذا المنشور؟')) {
          event.preventDefault();
        }
      });
    });
  }
}

// تهيئة جميع الوظائف عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', function() {
  initContentEditor();
  validatePostForm();
  initCommentForm();
  loadMorePosts();
  confirmPostDelete();
  
  // إضافة تاريخ السنة الحالية في تذييل الصفحة
  const yearElement = document.getElementById('currentYear');
  if (yearElement) {
    yearElement.textContent = new Date().getFullYear();
  }
});
