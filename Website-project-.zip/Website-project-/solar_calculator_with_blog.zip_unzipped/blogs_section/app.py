"""
وحدة واجهة المستخدم لإدارة المنشورات
توفر هذه الوحدة واجهة مستخدم بسيطة للتفاعل مع Blogger API
"""

from flask import Flask, render_template, request, redirect, url_for, flash, session
import os
from ..api.blogger.blogger_api import BloggerAPI

app = Flask(__name__, 
            template_folder=os.path.join(os.path.dirname(os.path.dirname(__file__)), 'templates'),
            static_folder=os.path.join(os.path.dirname(os.path.dirname(__file__)), 'static'))
app.secret_key = 'solar_panel_blog_secret_key'

blogger_api = BloggerAPI()

@app.route('/')
def index():
    """صفحة المدونة الرئيسية"""
    try:
        posts = blogger_api.list_posts(max_results=10)
        return render_template('blog/index.html', posts=posts.get('items', []))
    except Exception as e:
        flash(f'حدث خطأ: {str(e)}', 'error')
        return render_template('blog/index.html', posts=[])

@app.route('/post/<post_id>')
def view_post(post_id):
    """عرض منشور محدد"""
    try:
        post = blogger_api.get_post(post_id)
        comments = blogger_api.list_comments(post_id)
        return render_template('blog/post.html', post=post, comments=comments.get('items', []))
    except Exception as e:
        flash(f'حدث خطأ: {str(e)}', 'error')
        return redirect(url_for('index'))

@app.route('/search')
def search():
    """البحث في المنشورات"""
    query = request.args.get('q', '')
    if not query:
        return redirect(url_for('index'))
    
    try:
        results = blogger_api.search_posts(query)
        return render_template('blog/search.html', query=query, posts=results.get('items', []))
    except Exception as e:
        flash(f'حدث خطأ: {str(e)}', 'error')
        return redirect(url_for('index'))

# واجهات المسؤول

@app.route('/admin')
def admin_index():
    """لوحة تحكم المسؤول"""
    if not session.get('authenticated'):
        return redirect(url_for('admin_login'))
    
    try:
        blog_info = blogger_api.get_blog_info()
        posts = blogger_api.list_posts(max_results=20)
        return render_template('admin/index.html', blog=blog_info, posts=posts.get('items', []))
    except Exception as e:
        flash(f'حدث خطأ: {str(e)}', 'error')
        return render_template('admin/index.html', blog={}, posts=[])

@app.route('/admin/login', methods=['GET', 'POST'])
def admin_login():
    """صفحة تسجيل دخول المسؤول"""
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        # هذا مجرد مثال بسيط، في الإنتاج يجب استخدام نظام مصادقة أكثر أمانًا
        if username == 'admin' and password == 'password':
            session['authenticated'] = True
            return redirect(url_for('admin_index'))
        else:
            flash('اسم المستخدم أو كلمة المرور غير صحيحة', 'error')
    
    return render_template('admin/login.html')

@app.route('/admin/logout')
def admin_logout():
    """تسجيل خروج المسؤول"""
    session.pop('authenticated', None)
    return redirect(url_for('index'))

@app.route('/admin/posts')
def admin_posts():
    """إدارة المنشورات"""
    if not session.get('authenticated'):
        return redirect(url_for('admin_login'))
    
    try:
        posts = blogger_api.list_posts(max_results=50)
        return render_template('admin/posts.html', posts=posts.get('items', []))
    except Exception as e:
        flash(f'حدث خطأ: {str(e)}', 'error')
        return render_template('admin/posts.html', posts=[])

@app.route('/admin/posts/new', methods=['GET', 'POST'])
def admin_new_post():
    """إنشاء منشور جديد"""
    if not session.get('authenticated'):
        return redirect(url_for('admin_login'))
    
    if request.method == 'POST':
        title = request.form.get('title')
        content = request.form.get('content')
        labels = request.form.get('labels', '').split(',')
        is_draft = 'is_draft' in request.form
        
        try:
            blogger_api.create_post(title, content, labels, is_draft)
            flash('تم إنشاء المنشور بنجاح', 'success')
            return redirect(url_for('admin_posts'))
        except Exception as e:
            flash(f'حدث خطأ: {str(e)}', 'error')
    
    return render_template('admin/post_form.html', post=None)

@app.route('/admin/posts/edit/<post_id>', methods=['GET', 'POST'])
def admin_edit_post(post_id):
    """تعديل منشور موجود"""
    if not session.get('authenticated'):
        return redirect(url_for('admin_login'))
    
    try:
        post = blogger_api.get_post(post_id)
    except Exception as e:
        flash(f'حدث خطأ: {str(e)}', 'error')
        return redirect(url_for('admin_posts'))
    
    if request.method == 'POST':
        title = request.form.get('title')
        content = request.form.get('content')
        labels = request.form.get('labels', '').split(',')
        
        try:
            blogger_api.update_post(post_id, title, content, labels)
            flash('تم تحديث المنشور بنجاح', 'success')
            return redirect(url_for('admin_posts'))
        except Exception as e:
            flash(f'حدث خطأ: {str(e)}', 'error')
    
    return render_template('admin/post_form.html', post=post)

@app.route('/admin/posts/delete/<post_id>', methods=['POST'])
def admin_delete_post(post_id):
    """حذف منشور"""
    if not session.get('authenticated'):
        return redirect(url_for('admin_login'))
    
    try:
        blogger_api.delete_post(post_id)
        flash('تم حذف المنشور بنجاح', 'success')
    except Exception as e:
        flash(f'حدث خطأ: {str(e)}', 'error')
    
    return redirect(url_for('admin_posts'))

@app.route('/admin/comments')
def admin_comments():
    """إدارة التعليقات"""
    if not session.get('authenticated'):
        return redirect(url_for('admin_login'))
    
    try:
        comments = blogger_api.list_comments(max_results=50)
        return render_template('admin/comments.html', comments=comments.get('items', []))
    except Exception as e:
        flash(f'حدث خطأ: {str(e)}', 'error')
        return render_template('admin/comments.html', comments=[])

@app.route('/admin/comments/approve/<post_id>/<comment_id>', methods=['POST'])
def admin_approve_comment(post_id, comment_id):
    """الموافقة على تعليق"""
    if not session.get('authenticated'):
        return redirect(url_for('admin_login'))
    
    try:
        blogger_api.approve_comment(post_id, comment_id)
        flash('تم الموافقة على التعليق بنجاح', 'success')
    except Exception as e:
        flash(f'حدث خطأ: {str(e)}', 'error')
    
    return redirect(url_for('admin_comments'))

@app.route('/admin/comments/spam/<post_id>/<comment_id>', methods=['POST'])
def admin_mark_comment_as_spam(post_id, comment_id):
    """تعليم تعليق كرسائل غير مرغوب فيها"""
    if not session.get('authenticated'):
        return redirect(url_for('admin_login'))
    
    try:
        blogger_api.mark_comment_as_spam(post_id, comment_id)
        flash('تم تعليم التعليق كرسائل غير مرغوب فيها بنجاح', 'success')
    except Exception as e:
        flash(f'حدث خطأ: {str(e)}', 'error')
    
    return redirect(url_for('admin_comments'))

@app.route('/admin/comments/delete/<post_id>/<comment_id>', methods=['POST'])
def admin_delete_comment(post_id, comment_id):
    """حذف تعليق"""
    if not session.get('authenticated'):
        return redirect(url_for('admin_login'))
    
    try:
        blogger_api.delete_comment(post_id, comment_id)
        flash('تم حذف التعليق بنجاح', 'success')
    except Exception as e:
        flash(f'حدث خطأ: {str(e)}', 'error')
    
    return redirect(url_for('admin_comments'))

if __name__ == '__main__':
    app.run(debug=True)
