"""
وحدة واجهة المستخدم لـ Search Console
توفر هذه الوحدة واجهة مستخدم للتفاعل مع Search Console API
"""

from flask import Blueprint, render_template, request, redirect, url_for, flash, session, jsonify
import os
from ..api.search_console.search_console_api import SearchConsoleAPI

search_console_bp = Blueprint('search_console', __name__)
search_console_api = SearchConsoleAPI()

@search_console_bp.route('/admin/search_console')
def admin_search_console():
    """صفحة إدارة Search Console"""
    if not session.get('authenticated'):
        return redirect(url_for('admin_login'))
    
    try:
        # الحصول على معلومات الموقع
        site_info = search_console_api.get_site_info()
        
        # الحصول على أهم استعلامات البحث
        top_queries = search_console_api.get_top_queries()
        
        # الحصول على قائمة خرائط الموقع
        sitemaps = search_console_api.list_sitemaps()
        
        return render_template('admin/search_console.html', 
                              site=site_info, 
                              top_queries=top_queries,
                              sitemaps=sitemaps)
    except Exception as e:
        flash(f'حدث خطأ: {str(e)}', 'error')
        return render_template('admin/search_console.html', 
                              site={}, 
                              top_queries={},
                              sitemaps={})

@search_console_bp.route('/admin/search_console/top_queries')
def admin_top_queries():
    """صفحة أهم استعلامات البحث"""
    if not session.get('authenticated'):
        return redirect(url_for('admin_login'))
    
    start_date = request.args.get('start_date')
    end_date = request.args.get('end_date')
    row_limit = request.args.get('row_limit', 10, type=int)
    
    try:
        report = search_console_api.get_top_queries(start_date, end_date, row_limit)
        return render_template('admin/top_queries.html', 
                              report=report,
                              start_date=start_date,
                              end_date=end_date,
                              row_limit=row_limit)
    except Exception as e:
        flash(f'حدث خطأ: {str(e)}', 'error')
        return render_template('admin/top_queries.html', 
                              report={},
                              start_date=start_date,
                              end_date=end_date,
                              row_limit=row_limit)

@search_console_bp.route('/admin/search_console/top_pages')
def admin_top_pages():
    """صفحة أهم الصفحات"""
    if not session.get('authenticated'):
        return redirect(url_for('admin_login'))
    
    start_date = request.args.get('start_date')
    end_date = request.args.get('end_date')
    row_limit = request.args.get('row_limit', 10, type=int)
    
    try:
        report = search_console_api.get_top_pages(start_date, end_date, row_limit)
        return render_template('admin/top_pages.html', 
                              report=report,
                              start_date=start_date,
                              end_date=end_date,
                              row_limit=row_limit)
    except Exception as e:
        flash(f'حدث خطأ: {str(e)}', 'error')
        return render_template('admin/top_pages.html', 
                              report={},
                              start_date=start_date,
                              end_date=end_date,
                              row_limit=row_limit)

@search_console_bp.route('/admin/search_console/search_analytics')
def admin_search_analytics():
    """صفحة تحليلات البحث"""
    if not session.get('authenticated'):
        return redirect(url_for('admin_login'))
    
    start_date = request.args.get('start_date')
    end_date = request.args.get('end_date')
    dimensions = request.args.getlist('dimensions')
    search_type = request.args.get('search_type', 'web')
    row_limit = request.args.get('row_limit', 10, type=int)
    
    try:
        report = search_console_api.get_search_analytics(
            start_date, end_date, dimensions, search_type, row_limit)
        return render_template('admin/search_analytics.html', 
                              report=report,
                              start_date=start_date,
                              end_date=end_date,
                              dimensions=dimensions,
                              search_type=search_type,
                              row_limit=row_limit)
    except Exception as e:
        flash(f'حدث خطأ: {str(e)}', 'error')
        return render_template('admin/search_analytics.html', 
                              report={},
                              start_date=start_date,
                              end_date=end_date,
                              dimensions=dimensions,
                              search_type=search_type,
                              row_limit=row_limit)

@search_console_bp.route('/admin/search_console/sitemaps')
def admin_sitemaps():
    """صفحة إدارة خرائط الموقع"""
    if not session.get('authenticated'):
        return redirect(url_for('admin_login'))
    
    try:
        sitemaps = search_console_api.list_sitemaps()
        return render_template('admin/sitemaps.html', 
                              sitemaps=sitemaps)
    except Exception as e:
        flash(f'حدث خطأ: {str(e)}', 'error')
        return render_template('admin/sitemaps.html', 
                              sitemaps={})

@search_console_bp.route('/admin/search_console/submit_sitemap', methods=['POST'])
def admin_submit_sitemap():
    """إرسال خريطة موقع"""
    if not session.get('authenticated'):
        return redirect(url_for('admin_login'))
    
    sitemap_url = request.form.get('sitemap_url')
    
    if not sitemap_url:
        flash('يرجى إدخال عنوان URL لخريطة الموقع', 'error')
        return redirect(url_for('search_console.admin_sitemaps'))
    
    try:
        result = search_console_api.submit_sitemap(sitemap_url)
        flash('تم إرسال خريطة الموقع بنجاح', 'success')
    except Exception as e:
        flash(f'حدث خطأ: {str(e)}', 'error')
    
    return redirect(url_for('search_console.admin_sitemaps'))

@search_console_bp.route('/admin/search_console/delete_sitemap', methods=['POST'])
def admin_delete_sitemap():
    """حذف خريطة موقع"""
    if not session.get('authenticated'):
        return redirect(url_for('admin_login'))
    
    sitemap_url = request.form.get('sitemap_url')
    
    if not sitemap_url:
        flash('يرجى إدخال عنوان URL لخريطة الموقع', 'error')
        return redirect(url_for('search_console.admin_sitemaps'))
    
    try:
        result = search_console_api.delete_sitemap(sitemap_url)
        flash('تم حذف خريطة الموقع بنجاح', 'success')
    except Exception as e:
        flash(f'حدث خطأ: {str(e)}', 'error')
    
    return redirect(url_for('search_console.admin_sitemaps'))

@search_console_bp.route('/admin/search_console/url_inspection')
def admin_url_inspection():
    """صفحة فحص عنوان URL"""
    if not session.get('authenticated'):
        return redirect(url_for('admin_login'))
    
    url = request.args.get('url')
    result = None
    
    if url:
        try:
            result = search_console_api.get_url_inspection(url)
        except Exception as e:
            flash(f'حدث خطأ: {str(e)}', 'error')
    
    return render_template('admin/url_inspection.html', 
                          url=url,
                          result=result)
