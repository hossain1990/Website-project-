"""
وحدة الترجمة التلقائية مع اكتشاف لغة المتصفح
توفر هذه الوحدة وظائف الترجمة التلقائية للمحتوى باستخدام واجهة برمجة الترجمة
"""

import os
import json
import requests
from flask import Blueprint, request, session, jsonify, g
from functools import wraps

# تكوين واجهة برمجة الترجمة
TRANSLATION_API_KEY = os.environ.get('TRANSLATION_API_KEY', 'your_api_key_here')
TRANSLATION_API_URL = 'https://translation.googleapis.com/language/translate/v2'
DEFAULT_LANGUAGE = 'ar'  # اللغة الافتراضية هي العربية
SUPPORTED_LANGUAGES = ['ar', 'en', 'fr', 'es', 'de', 'it', 'ru', 'zh', 'ja', 'ko']

translation_bp = Blueprint('translation', __name__)

def get_browser_language():
    """
    استخراج لغة المتصفح من رأس Accept-Language
    
    العائد:
        str: رمز اللغة بتنسيق ISO 639-1 (مثل 'ar', 'en', إلخ)
    """
    # الحصول على رأس Accept-Language
    accept_language = request.headers.get('Accept-Language', '')
    
    if not accept_language:
        return DEFAULT_LANGUAGE
    
    # تحليل رأس Accept-Language
    # مثال: 'en-US,en;q=0.9,ar;q=0.8'
    languages = []
    for lang_q in accept_language.split(','):
        parts = lang_q.split(';q=')
        lang = parts[0].strip().split('-')[0].lower()
        q = float(parts[1]) if len(parts) > 1 else 1.0
        languages.append((lang, q))
    
    # ترتيب اللغات حسب الأفضلية
    languages.sort(key=lambda x: x[1], reverse=True)
    
    # إرجاع اللغة الأكثر تفضيلاً المدعومة
    for lang, _ in languages:
        if lang in SUPPORTED_LANGUAGES:
            return lang
    
    # إرجاع اللغة الافتراضية إذا لم تكن أي لغة مدعومة
    return DEFAULT_LANGUAGE

def translate_text(text, target_language, source_language=None):
    """
    ترجمة نص باستخدام واجهة برمجة الترجمة
    
    المعلمات:
        text (str): النص المراد ترجمته
        target_language (str): اللغة الهدف
        source_language (str, optional): لغة المصدر. إذا لم يتم تحديدها، سيتم اكتشافها تلقائياً
    
    العائد:
        str: النص المترجم
    """
    if not text or target_language == source_language:
        return text
    
    # إعداد بيانات الطلب
    data = {
        'q': text,
        'target': target_language,
        'key': TRANSLATION_API_KEY
    }
    
    if source_language:
        data['source'] = source_language
    
    try:
        # إرسال طلب الترجمة
        response = requests.post(TRANSLATION_API_URL, data=data)
        response.raise_for_status()
        
        # تحليل الاستجابة
        result = response.json()
        translated_text = result['data']['translations'][0]['translatedText']
        
        return translated_text
    except Exception as e:
        print(f"خطأ في الترجمة: {str(e)}")
        return text

def translate_content(content, target_language):
    """
    ترجمة محتوى المدونة
    
    المعلمات:
        content (dict): محتوى المدونة
        target_language (str): اللغة الهدف
    
    العائد:
        dict: محتوى المدونة المترجم
    """
    if not content or target_language == DEFAULT_LANGUAGE:
        return content
    
    # نسخة من المحتوى للترجمة
    translated_content = content.copy()
    
    # ترجمة الحقول النصية
    if isinstance(content, dict):
        for key, value in content.items():
            if key in ['title', 'subtitle', 'summary', 'content', 'description']:
                if isinstance(value, str):
                    translated_content[key] = translate_text(value, target_language, DEFAULT_LANGUAGE)
            elif isinstance(value, (dict, list)):
                translated_content[key] = translate_content(value, target_language)
    elif isinstance(content, list):
        translated_content = [translate_content(item, target_language) for item in content]
    
    return translated_content

def with_auto_translation(view_function):
    """
    مزخرف لإضافة الترجمة التلقائية إلى وظائف العرض
    
    المعلمات:
        view_function (function): وظيفة العرض المراد تزيينها
    
    العائد:
        function: وظيفة العرض المزينة
    """
    @wraps(view_function)
    def decorated_function(*args, **kwargs):
        # تحديد لغة المستخدم
        user_language = session.get('language') or get_browser_language()
        
        # تخزين اللغة في g للاستخدام في القوالب
        g.language = user_language
        
        # تنفيذ وظيفة العرض الأصلية
        response = view_function(*args, **kwargs)
        
        # إذا كانت الاستجابة تحتوي على بيانات JSON، ترجمة المحتوى
        if hasattr(response, 'json'):
            data = response.json
            translated_data = translate_content(data, user_language)
            return jsonify(translated_data)
        
        return response
    
    return decorated_function

@translation_bp.route('/api/set_language', methods=['POST'])
def set_language():
    """
    تعيين لغة المستخدم
    """
    data = request.get_json()
    language = data.get('language')
    
    if language and language in SUPPORTED_LANGUAGES:
        session['language'] = language
        return jsonify({'success': True, 'language': language})
    
    return jsonify({'success': False, 'error': 'لغة غير مدعومة'}), 400

@translation_bp.route('/api/translate', methods=['POST'])
def translate_api():
    """
    واجهة برمجة للترجمة
    """
    data = request.get_json()
    text = data.get('text')
    target_language = data.get('target_language') or session.get('language') or get_browser_language()
    source_language = data.get('source_language') or DEFAULT_LANGUAGE
    
    if not text:
        return jsonify({'success': False, 'error': 'النص مطلوب'}), 400
    
    if target_language not in SUPPORTED_LANGUAGES:
        return jsonify({'success': False, 'error': 'لغة الهدف غير مدعومة'}), 400
    
    translated_text = translate_text(text, target_language, source_language)
    
    return jsonify({
        'success': True,
        'original_text': text,
        'translated_text': translated_text,
        'source_language': source_language,
        'target_language': target_language
    })

@translation_bp.context_processor
def translation_context():
    """
    إضافة متغيرات الترجمة إلى سياق القالب
    """
    return {
        'current_language': session.get('language') or get_browser_language(),
        'supported_languages': SUPPORTED_LANGUAGES,
        'default_language': DEFAULT_LANGUAGE
    }
