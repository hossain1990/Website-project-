"""
وحدة التكامل مع Google Analytics API
توفر هذه الوحدة الوظائف اللازمة للتفاعل مع Google Analytics API
"""

import os
from googleapiclient.discovery import build
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
import pickle
import json
import datetime

from ..config import api_config

class AnalyticsAPI:
    """فئة للتعامل مع Google Analytics API"""
    
    def __init__(self):
        """تهيئة الاتصال بـ Google Analytics API"""
        self.scopes = api_config.ANALYTICS_SCOPES
        self.api_key = api_config.ANALYTICS_API_KEY
        self.property_id = api_config.ANALYTICS_PROPERTY_ID
        self.creds = None
        self.service = None
    
    def authenticate(self):
        """إجراء المصادقة مع Google Analytics API"""
        # التحقق من وجود ملف التوكن
        token_path = os.path.join(os.path.dirname(__file__), 'analytics_token.pickle')
        
        if os.path.exists(token_path):
            with open(token_path, 'rb') as token:
                self.creds = pickle.load(token)
        
        # إذا لم تكن هناك بيانات اعتماد صالحة، قم بإنشاء جديدة
        if not self.creds or not self.creds.valid:
            if self.creds and self.creds.expired and self.creds.refresh_token:
                self.creds.refresh(Request())
            else:
                # إنشاء ملف client_secrets.json
                client_config = {
                    "installed": {
                        "client_id": api_config.CLIENT_ID,
                        "client_secret": api_config.CLIENT_SECRET,
                        "redirect_uris": [api_config.REDIRECT_URI, "urn:ietf:wg:oauth:2.0:oob"],
                        "auth_uri": "https://accounts.google.com/o/oauth2/auth",
                        "token_uri": "https://oauth2.googleapis.com/token"
                    }
                }
                
                client_secrets_path = os.path.join(os.path.dirname(__file__), 'analytics_client_secrets.json')
                with open(client_secrets_path, 'w') as f:
                    json.dump(client_config, f)
                
                flow = InstalledAppFlow.from_client_secrets_file(
                    client_secrets_path, self.scopes)
                self.creds = flow.run_local_server(port=0)
            
            # حفظ بيانات الاعتماد للمرة القادمة
            with open(token_path, 'wb') as token:
                pickle.dump(self.creds, token)
        
        # إنشاء خدمة Google Analytics API
        self.service = build('analyticsdata', 'v1beta', credentials=self.creds)
        return self.service
    
    def get_property_info(self):
        """الحصول على معلومات الخاصية"""
        if not self.service:
            self.authenticate()
        
        # إنشاء خدمة Admin API للحصول على معلومات الخاصية
        admin_service = build('analyticsadmin', 'v1alpha', credentials=self.creds)
        
        return admin_service.properties().get(
            name=f'properties/{self.property_id}'
        ).execute()
    
    def get_metadata(self):
        """الحصول على البيانات الوصفية للأبعاد والمقاييس المتاحة"""
        if not self.service:
            self.authenticate()
        
        return self.service.properties().getMetadata(
            name=f'properties/{self.property_id}/metadata'
        ).execute()
    
    def run_report(self, start_date=None, end_date=None, dimensions=None, metrics=None, limit=10):
        """تشغيل تقرير تحليلي
        
        المعلمات:
            start_date (str): تاريخ البداية بتنسيق YYYY-MM-DD
            end_date (str): تاريخ النهاية بتنسيق YYYY-MM-DD
            dimensions (list): قائمة الأبعاد
            metrics (list): قائمة المقاييس
            limit (int): الحد الأقصى لعدد النتائج
        
        العائد:
            dict: نتائج التقرير
        """
        if not self.service:
            self.authenticate()
        
        # إذا لم يتم تحديد التواريخ، استخدم الشهر الحالي
        if not start_date or not end_date:
            today = datetime.date.today()
            end_date = today.strftime('%Y-%m-%d')
            start_date = (today - datetime.timedelta(days=30)).strftime('%Y-%m-%d')
        
        # إذا لم يتم تحديد الأبعاد، استخدم البعد الافتراضي (التاريخ)
        if not dimensions:
            dimensions = ['date']
        
        # إذا لم يتم تحديد المقاييس، استخدم المقاييس الافتراضية
        if not metrics:
            metrics = ['activeUsers', 'screenPageViews', 'sessions', 'averageSessionDuration']
        
        # إعداد طلب التقرير
        request = {
            'property': f'properties/{self.property_id}',
            'dateRanges': [{'startDate': start_date, 'endDate': end_date}],
            'dimensions': [{'name': dim} for dim in dimensions],
            'metrics': [{'name': metric} for metric in metrics],
            'limit': limit
        }
        
        return self.service.properties().runReport(
            property=f'properties/{self.property_id}',
            body=request
        ).execute()
    
    def get_realtime_report(self, dimensions=None, metrics=None, limit=10):
        """الحصول على تقرير في الوقت الحقيقي
        
        المعلمات:
            dimensions (list): قائمة الأبعاد
            metrics (list): قائمة المقاييس
            limit (int): الحد الأقصى لعدد النتائج
        
        العائد:
            dict: نتائج التقرير في الوقت الحقيقي
        """
        if not self.service:
            self.authenticate()
        
        # إذا لم يتم تحديد الأبعاد، استخدم البعد الافتراضي (المدينة)
        if not dimensions:
            dimensions = ['city']
        
        # إذا لم يتم تحديد المقاييس، استخدم المقاييس الافتراضية
        if not metrics:
            metrics = ['activeUsers']
        
        # إعداد طلب التقرير
        request = {
            'dimensions': [{'name': dim} for dim in dimensions],
            'metrics': [{'name': metric} for metric in metrics],
            'limit': limit
        }
        
        return self.service.properties().runRealtimeReport(
            property=f'properties/{self.property_id}',
            body=request
        ).execute()
    
    def get_popular_pages(self, start_date=None, end_date=None, limit=10):
        """الحصول على الصفحات الأكثر شعبية
        
        المعلمات:
            start_date (str): تاريخ البداية بتنسيق YYYY-MM-DD
            end_date (str): تاريخ النهاية بتنسيق YYYY-MM-DD
            limit (int): الحد الأقصى لعدد النتائج
        
        العائد:
            dict: نتائج التقرير
        """
        return self.run_report(
            start_date=start_date,
            end_date=end_date,
            dimensions=['pagePath', 'pageTitle'],
            metrics=['screenPageViews', 'activeUsers', 'averageSessionDuration'],
            limit=limit
        )
    
    def get_traffic_sources(self, start_date=None, end_date=None, limit=10):
        """الحصول على مصادر حركة المرور
        
        المعلمات:
            start_date (str): تاريخ البداية بتنسيق YYYY-MM-DD
            end_date (str): تاريخ النهاية بتنسيق YYYY-MM-DD
            limit (int): الحد الأقصى لعدد النتائج
        
        العائد:
            dict: نتائج التقرير
        """
        return self.run_report(
            start_date=start_date,
            end_date=end_date,
            dimensions=['sessionSource', 'sessionMedium'],
            metrics=['sessions', 'activeUsers', 'screenPageViews'],
            limit=limit
        )
    
    def get_user_demographics(self, start_date=None, end_date=None, limit=10):
        """الحصول على بيانات ديموغرافية للمستخدمين
        
        المعلمات:
            start_date (str): تاريخ البداية بتنسيق YYYY-MM-DD
            end_date (str): تاريخ النهاية بتنسيق YYYY-MM-DD
            limit (int): الحد الأقصى لعدد النتائج
        
        العائد:
            dict: نتائج التقرير
        """
        return self.run_report(
            start_date=start_date,
            end_date=end_date,
            dimensions=['country', 'city'],
            metrics=['activeUsers', 'sessions', 'screenPageViews'],
            limit=limit
        )
    
    def get_user_devices(self, start_date=None, end_date=None, limit=10):
        """الحصول على أجهزة المستخدمين
        
        المعلمات:
            start_date (str): تاريخ البداية بتنسيق YYYY-MM-DD
            end_date (str): تاريخ النهاية بتنسيق YYYY-MM-DD
            limit (int): الحد الأقصى لعدد النتائج
        
        العائد:
            dict: نتائج التقرير
        """
        return self.run_report(
            start_date=start_date,
            end_date=end_date,
            dimensions=['deviceCategory', 'operatingSystem', 'browser'],
            metrics=['activeUsers', 'sessions', 'screenPageViews'],
            limit=limit
        )
    
    def get_tracking_code(self):
        """الحصول على كود تتبع Google Analytics
        
        العائد:
            str: كود تتبع Google Analytics
        """
        # هذا مثال لكود تتبع Google Analytics 4
        tracking_code = f"""
        <!-- Global site tag (gtag.js) - Google Analytics -->
        <script async src="https://www.googletagmanager.com/gtag/js?id=G-{self.property_id}"></script>
        <script>
          window.dataLayer = window.dataLayer || [];
          function gtag(){{dataLayer.push(arguments);}}
          gtag('js', new Date());
          
          gtag('config', 'G-{self.property_id}');
        </script>
        """
        
        return tracking_code
