"""
وحدة التكامل مع AdSense API
توفر هذه الوحدة الوظائف اللازمة للتفاعل مع AdSense API
"""

import os
from googleapiclient.discovery import build
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
import pickle
import json
import datetime

from ..config import api_config

class AdSenseAPI:
    """فئة للتعامل مع AdSense API"""
    
    def __init__(self):
        """تهيئة الاتصال بـ AdSense API"""
        self.scopes = api_config.ADSENSE_SCOPES
        self.api_key = api_config.ADSENSE_API_KEY
        self.account_id = api_config.ADSENSE_ACCOUNT_ID
        self.creds = None
        self.service = None
    
    def authenticate(self):
        """إجراء المصادقة مع AdSense API"""
        # التحقق من وجود ملف التوكن
        token_path = os.path.join(os.path.dirname(__file__), 'adsense_token.pickle')
        
        if os.path.exists(token_path):
            with open(token_path, 'rb') as token:
                self.creds = pickle.load(token)
        
        # إذا لم تكن هناك بيانات اعتماد صالحة، قم بإنشاء جديدة
        if not self.creds or not self.creds.valid:
            if self.creds and self.creds.expired and self.creds.refresh_token:
                self.creds.refresh(Request())
            else:
                # إنشاء ملف client_secrets.json
                client_config = {
                    "installed": {
                        "client_id": api_config.CLIENT_ID,
                        "client_secret": api_config.CLIENT_SECRET,
                        "redirect_uris": [api_config.REDIRECT_URI, "urn:ietf:wg:oauth:2.0:oob"],
                        "auth_uri": "https://accounts.google.com/o/oauth2/auth",
                        "token_uri": "https://oauth2.googleapis.com/token"
                    }
                }
                
                client_secrets_path = os.path.join(os.path.dirname(__file__), 'adsense_client_secrets.json')
                with open(client_secrets_path, 'w') as f:
                    json.dump(client_config, f)
                
                flow = InstalledAppFlow.from_client_secrets_file(
                    client_secrets_path, self.scopes)
                self.creds = flow.run_local_server(port=0)
            
            # حفظ بيانات الاعتماد للمرة القادمة
            with open(token_path, 'wb') as token:
                pickle.dump(self.creds, token)
        
        # إنشاء خدمة AdSense API
        self.service = build('adsense', 'v2', credentials=self.creds)
        return self.service
    
    def get_account_info(self):
        """الحصول على معلومات الحساب"""
        if not self.service:
            self.authenticate()
        
        return self.service.accounts().get(name=f'accounts/{self.account_id}').execute()
    
    def list_ad_clients(self):
        """الحصول على قائمة عملاء الإعلانات"""
        if not self.service:
            self.authenticate()
        
        return self.service.accounts().adclients().list(
            parent=f'accounts/{self.account_id}'
        ).execute()
    
    def list_ad_units(self, ad_client_id):
        """الحصول على قائمة وحدات الإعلانات
        
        المعلمات:
            ad_client_id (str): معرف عميل الإعلانات
        
        العائد:
            dict: قائمة وحدات الإعلانات
        """
        if not self.service:
            self.authenticate()
        
        return self.service.accounts().adclients().adunits().list(
            parent=f'accounts/{self.account_id}/adclients/{ad_client_id}'
        ).execute()
    
    def get_ad_unit(self, ad_client_id, ad_unit_id):
        """الحصول على معلومات وحدة إعلانية محددة
        
        المعلمات:
            ad_client_id (str): معرف عميل الإعلانات
            ad_unit_id (str): معرف وحدة الإعلانات
        
        العائد:
            dict: معلومات وحدة الإعلانات
        """
        if not self.service:
            self.authenticate()
        
        return self.service.accounts().adclients().adunits().get(
            name=f'accounts/{self.account_id}/adclients/{ad_client_id}/adunits/{ad_unit_id}'
        ).execute()
    
    def get_account_earnings(self, start_date=None, end_date=None):
        """الحصول على تقرير أرباح الحساب
        
        المعلمات:
            start_date (str): تاريخ البداية بتنسيق YYYY-MM-DD
            end_date (str): تاريخ النهاية بتنسيق YYYY-MM-DD
        
        العائد:
            dict: تقرير الأرباح
        """
        if not self.service:
            self.authenticate()
        
        # إذا لم يتم تحديد التواريخ، استخدم الشهر الحالي
        if not start_date or not end_date:
            today = datetime.date.today()
            first_day = today.replace(day=1)
            end_date = today.strftime('%Y-%m-%d')
            start_date = first_day.strftime('%Y-%m-%d')
        
        return self.service.accounts().reports().generate(
            account=f'accounts/{self.account_id}',
            dateRange='CUSTOM',
            startDate_year=int(start_date.split('-')[0]),
            startDate_month=int(start_date.split('-')[1]),
            startDate_day=int(start_date.split('-')[2]),
            endDate_year=int(end_date.split('-')[0]),
            endDate_month=int(end_date.split('-')[1]),
            endDate_day=int(end_date.split('-')[2]),
            metrics=['ESTIMATED_EARNINGS', 'PAGE_VIEWS', 'IMPRESSIONS', 'CLICKS', 'PAGE_VIEWS_RPM', 'IMPRESSIONS_CTR']
        ).execute()
    
    def get_ad_unit_earnings(self, ad_unit_id, start_date=None, end_date=None):
        """الحصول على تقرير أرباح وحدة إعلانية محددة
        
        المعلمات:
            ad_unit_id (str): معرف وحدة الإعلانات
            start_date (str): تاريخ البداية بتنسيق YYYY-MM-DD
            end_date (str): تاريخ النهاية بتنسيق YYYY-MM-DD
        
        العائد:
            dict: تقرير الأرباح
        """
        if not self.service:
            self.authenticate()
        
        # إذا لم يتم تحديد التواريخ، استخدم الشهر الحالي
        if not start_date or not end_date:
            today = datetime.date.today()
            first_day = today.replace(day=1)
            end_date = today.strftime('%Y-%m-%d')
            start_date = first_day.strftime('%Y-%m-%d')
        
        return self.service.accounts().reports().generate(
            account=f'accounts/{self.account_id}',
            dateRange='CUSTOM',
            startDate_year=int(start_date.split('-')[0]),
            startDate_month=int(start_date.split('-')[1]),
            startDate_day=int(start_date.split('-')[2]),
            endDate_year=int(end_date.split('-')[0]),
            endDate_month=int(end_date.split('-')[1]),
            endDate_day=int(end_date.split('-')[2]),
            metrics=['ESTIMATED_EARNINGS', 'PAGE_VIEWS', 'IMPRESSIONS', 'CLICKS', 'PAGE_VIEWS_RPM', 'IMPRESSIONS_CTR'],
            filters=[f'AD_UNIT_ID=={ad_unit_id}']
        ).execute()
    
    def get_ad_code(self, ad_client_id, ad_unit_id):
        """الحصول على كود الإعلان لوحدة إعلانية محددة
        
        المعلمات:
            ad_client_id (str): معرف عميل الإعلانات
            ad_unit_id (str): معرف وحدة الإعلانات
        
        العائد:
            str: كود الإعلان
        """
        if not self.service:
            self.authenticate()
        
        ad_unit = self.get_ad_unit(ad_client_id, ad_unit_id)
        
        # إنشاء كود الإعلان (هذا مثال فقط، في الواقع يتم الحصول عليه من AdSense)
        ad_code = f"""
        <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
        <!-- {ad_unit.get('displayName', 'Ad Unit')} -->
        <ins class="adsbygoogle"
             style="display:block"
             data-ad-client="ca-pub-{ad_client_id}"
             data-ad-slot="{ad_unit_id}"
             data-ad-format="auto"
             data-full-width-responsive="true"></ins>
        <script>
             (adsbygoogle = window.adsbygoogle || []).push({});
        </script>
        """
        
        return ad_code
    
    def generate_responsive_ad_code(self, ad_client_id):
        """إنشاء كود إعلان متجاوب
        
        المعلمات:
            ad_client_id (str): معرف عميل الإعلانات
        
        العائد:
            str: كود الإعلان المتجاوب
        """
        # هذا مثال لكود إعلان متجاوب
        ad_code = f"""
        <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
        <ins class="adsbygoogle"
             style="display:block"
             data-ad-client="ca-pub-{ad_client_id}"
             data-ad-slot="AUTO_GENERATED_SLOT"
             data-ad-format="auto"
             data-full-width-responsive="true"></ins>
        <script>
             (adsbygoogle = window.adsbygoogle || []).push({});
        </script>
        """
        
        return ad_code
    
    def generate_in_article_ad_code(self, ad_client_id):
        """إنشاء كود إعلان داخل المقال
        
        المعلمات:
            ad_client_id (str): معرف عميل الإعلانات
        
        العائد:
            str: كود الإعلان داخل المقال
        """
        # هذا مثال لكود إعلان داخل المقال
        ad_code = f"""
        <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
        <ins class="adsbygoogle"
             style="display:block; text-align:center;"
             data-ad-layout="in-article"
             data-ad-format="fluid"
             data-ad-client="ca-pub-{ad_client_id}"
             data-ad-slot="AUTO_GENERATED_SLOT"></ins>
        <script>
             (adsbygoogle = window.adsbygoogle || []).push({});
        </script>
        """
        
        return ad_code
    
    def generate_auto_ads_code(self, ad_client_id):
        """إنشاء كود الإعلانات التلقائية
        
        المعلمات:
            ad_client_id (str): معرف عميل الإعلانات
        
        العائد:
            str: كود الإعلانات التلقائية
        """
        # هذا مثال لكود الإعلانات التلقائية
        ad_code = f"""
        <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
        <script>
             (adsbygoogle = window.adsbygoogle || []).push({
                  google_ad_client: "ca-pub-{ad_client_id}",
                  enable_page_level_ads: true
             });
        </script>
        """
        
        return ad_code
