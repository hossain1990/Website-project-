"""
اختبار تكامل واجهة المستخدم لقسم المدونات
"""

import os
import sys
import unittest
from unittest.mock import MagicMock, patch
from flask import Flask, template_rendered
from contextlib import contextmanager

# إضافة المسار إلى المشروع
sys.path.append('/home/ubuntu/blogs_section')

# استيراد الوحدات المطلوبة للاختبار
from app import create_app

@contextmanager
def captured_templates(app):
    """سياق لالتقاط القوالب المعروضة"""
    recorded = []
    def record(sender, template, context, **extra):
        recorded.append((template, context))
    template_rendered.connect(record, app)
    try:
        yield recorded
    finally:
        template_rendered.disconnect(record, app)

class TestUIIntegration(unittest.TestCase):
    """اختبار تكامل واجهة المستخدم"""
    
    def setUp(self):
        """إعداد بيئة الاختبار"""
        # إنشاء تطبيق اختبار
        self.app = create_app(testing=True)
        self.client = self.app.test_client()
        self.app_context = self.app.app_context()
        self.app_context.push()
    
    def tearDown(self):
        """تنظيف بيئة الاختبار"""
        self.app_context.pop()
    
    def test_blog_index_page(self):
        """اختبار صفحة المدونة الرئيسية"""
        with captured_templates(self.app) as templates:
            response = self.client.get('/blog')
            self.assertEqual(response.status_code, 200)
            
            # التحقق من استخدام القالب الصحيح
            self.assertEqual(len(templates), 1)
            template, context = templates[0]
            self.assertEqual(template.name, 'blog/index.html')
            
            # التحقق من وجود البيانات المطلوبة في السياق
            self.assertIn('posts', context)
    
    def test_blog_post_page(self):
        """اختبار صفحة المنشور الفردي"""
        with captured_templates(self.app) as templates:
            # استخدام معرف منشور وهمي للاختبار
            response = self.client.get('/blog/post/1')
            self.assertEqual(response.status_code, 200)
            
            # التحقق من استخدام القالب الصحيح
            self.assertEqual(len(templates), 1)
            template, context = templates[0]
            self.assertEqual(template.name, 'blog/post.html')
            
            # التحقق من وجود البيانات المطلوبة في السياق
            self.assertIn('post', context)
    
    def test_admin_dashboard(self):
        """اختبار لوحة تحكم المدونة"""
        with captured_templates(self.app) as templates:
            # محاكاة تسجيل الدخول
            with self.client.session_transaction() as session:
                session['authenticated'] = True
            
            response = self.client.get('/admin/blog')
            self.assertEqual(response.status_code, 200)
            
            # التحقق من استخدام القالب الصحيح
            self.assertEqual(len(templates), 1)
            template, context = templates[0]
            self.assertEqual(template.name, 'admin/blog_dashboard.html')
    
    def test_admin_new_post(self):
        """اختبار إنشاء منشور جديد"""
        # محاكاة تسجيل الدخول
        with self.client.session_transaction() as session:
            session['authenticated'] = True
        
        # بيانات المنشور الجديد
        post_data = {
            'title': 'منشور اختبار',
            'subtitle': 'وصف فرعي للمنشور',
            'content': 'محتوى المنشور الاختباري',
            'category': 'تكنولوجيا',
            'status': 'published',
            'tags': 'اختبار,تجربة'
        }
        
        response = self.client.post('/admin/blog/new', data=post_data, follow_redirects=True)
        self.assertEqual(response.status_code, 200)
        
        # التحقق من وجود رسالة نجاح
        self.assertIn('تم إنشاء المنشور بنجاح', response.get_data(as_text=True))
    
    def test_admin_edit_post(self):
        """اختبار تعديل منشور"""
        # محاكاة تسجيل الدخول
        with self.client.session_transaction() as session:
            session['authenticated'] = True
        
        # بيانات تعديل المنشور
        edit_data = {
            'title': 'عنوان معدل',
            'subtitle': 'وصف فرعي معدل',
            'content': 'محتوى معدل للمنشور',
            'category': 'نصائح',
            'status': 'published',
            'tags': 'اختبار,تعديل'
        }
        
        # استخدام معرف منشور وهمي للاختبار
        response = self.client.post('/admin/blog/edit/1', data=edit_data, follow_redirects=True)
        self.assertEqual(response.status_code, 200)
        
        # التحقق من وجود رسالة نجاح
        self.assertIn('تم تحديث المنشور بنجاح', response.get_data(as_text=True))
    
    def test_admin_delete_post(self):
        """اختبار حذف منشور"""
        # محاكاة تسجيل الدخول
        with self.client.session_transaction() as session:
            session['authenticated'] = True
        
        # استخدام معرف منشور وهمي للاختبار
        response = self.client.post('/admin/blog/delete/1', follow_redirects=True)
        self.assertEqual(response.status_code, 200)
        
        # التحقق من وجود رسالة نجاح
        self.assertIn('تم حذف المنشور بنجاح', response.get_data(as_text=True))
    
    def test_admin_adsense_page(self):
        """اختبار صفحة إدارة AdSense"""
        # محاكاة تسجيل الدخول
        with self.client.session_transaction() as session:
            session['authenticated'] = True
        
        with captured_templates(self.app) as templates:
            response = self.client.get('/admin/adsense')
            self.assertEqual(response.status_code, 200)
            
            # التحقق من استخدام القالب الصحيح
            self.assertEqual(len(templates), 1)
            template, context = templates[0]
            self.assertEqual(template.name, 'admin/adsense.html')
    
    def test_admin_analytics_page(self):
        """اختبار صفحة إدارة Analytics"""
        # محاكاة تسجيل الدخول
        with self.client.session_transaction() as session:
            session['authenticated'] = True
        
        with captured_templates(self.app) as templates:
            response = self.client.get('/admin/analytics')
            self.assertEqual(response.status_code, 200)
            
            # التحقق من استخدام القالب الصحيح
            self.assertEqual(len(templates), 1)
            template, context = templates[0]
            self.assertEqual(template.name, 'admin/analytics.html')
    
    def test_admin_search_console_page(self):
        """اختبار صفحة إدارة Search Console"""
        # محاكاة تسجيل الدخول
        with self.client.session_transaction() as session:
            session['authenticated'] = True
        
        with captured_templates(self.app) as templates:
            response = self.client.get('/admin/search_console')
            self.assertEqual(response.status_code, 200)
            
            # التحقق من استخدام القالب الصحيح
            self.assertEqual(len(templates), 1)
            template, context = templates[0]
            self.assertEqual(template.name, 'admin/search_console.html')

if __name__ == '__main__':
    unittest.main()
